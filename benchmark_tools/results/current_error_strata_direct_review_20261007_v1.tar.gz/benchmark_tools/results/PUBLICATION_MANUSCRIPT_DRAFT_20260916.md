# OrthoHMM: HMM-Centered Orthogroup Inference And Phylogenetic Refinement

A [condensed scientific main text](PUBLICATION_MAIN_TEXT_20260927.md) provides
the current narrative; this extended draft retains detailed audit history.

Working manuscript, updated 2 October 2026. Not submission-ready. Sections below
distinguish completed development-exposed analyses from prospective work.
Internal evidence links are supplied for audit. The
[selected bibliography](publication_bibliography_20260920_v5.csl.json) contains
37 records. Its [provenance and review history](PUBLICATION_MANUSCRIPT_BIBLIOGRAPHY_PROVENANCE_20260925.md)
are retained separately; citation coverage and journal-specific formatting
remain incomplete.

## Study Objective

We evaluate an HMM-centered approach to orthogroup inference and its
integration with phylogenetic refinement. The principal questions are whether
profile-based expansion contributes measurable recovery beyond the initial
search, whether broader candidate groups improve reconciliation, and how
accuracy and computational costs compare with established tools. These
questions are not equivalent to asking whether a single aggregate score is
maximized. We distinguish homolog-group recovery, resolved ortholog-pair
prediction, and conserved-family recovery throughout the study.

## Methods

### Configurations And Comparator Outputs

The retained OrthoHMM configurations are high sensitivity and the
satellite_v2 phylogenetic pipeline. The prospective validation configuration
is pinned to source revision `7f3a9e4`, with BLOSUM62, E-value threshold
1e-4, Leiden CPM resolution 0.1, seed 4, and the default refinement profile.
The Leiden optimizer is described by [Traag et al. (2019)](https://doi.org/10.1038/s41598-019-41695-z)
and the CPM objective by [Traag et al. (2011)](https://doi.org/10.1103/PhysRevE.84.016114).
These clustering references do not imply biological orthology guarantees.
The graph library is cited separately as
[Csardi and Nepusz (2006), igraph](https://igraph.org);
runtime manifests, not this citation, identify executed library versions.
The phylogenetic configuration uses satellite_v2 candidate expansion,
an internally inferred species tree, minimum-variance species-tree rooting,
the species-overlap root rule, and positive-paralogy pair inference.
Historical runs retain their actual source and configuration records; the
prospective pin must not be retroactively attributed to them.
See the [frozen validation protocol](YGOB_VALIDATION_PROTOCOL_20260916.md).
The original OrthoHMM lineage is cited as the
[Steenwyk et al. (2024) preprint](https://doi.org/10.1101/2024.12.07.627370);
the implementation examined here includes later changes that require
the source/runtime description rather than attribution to that preprint alone.

The [method diagram](figures_publication_method_20260916/publication_method.pdf)
distinguishes initial HMM search, cluster-profile expansion, high-sensitivity
orthogroups, candidate-family construction, gene/species-tree inference and
constraint-guided membership decisions. Root HOGs and inferred ortholog pairs
are separate output levels. This schematic describes the intended frozen
workflow, not evidence of execution correctness or an HMM accuracy advantage.

The [exact frozen search specification](FROZEN_HMM_SCORING_SPECIFICATION_20260930.md)
defines integer match/insert/delete local Viterbi recurrences, uniform transition
costs, banding, the approximate static-parameter E-value filter, one-time initial
length normalization, MSA pseudocount emissions and strict profile acceptance.
It distinguishes learned match emissions from fixed transitions and raw profile
scores from initial length-normalized graph evidence. The implementation does
not establish HMMER/phmmer equivalence or calibrated assignment confidence;
the matrix-table gap-cost comment differs from the actual scorer costs.
This documentation amendment changes no frozen method, scores or defaults.

The [synthetic null-score protocol](FROZEN_NULL_SCORE_PROTOCOL_20261002.md)
was committed as `186bd5e47ecaa9361a86064c33d7a57c70ce1ce3` before study scoring.
For each of three lengths (50, 150, 400) and three independent-residue
compositions (normalized BLOSUM background, uniform, and half background plus
half glutamine), ten PCG64 seed streams supplied 1,000 independent query-target
pairs. Seeds used `SeedSequence([20261002, seed, regime_index, length])` with
query draws preceding target draws. Each pair had its own one-target database;
full and width-64 scalar C scores are dependent observations of the same pair.
The design contains 90,000 independent pairs and 180,000 evaluations, not
180,000 independent units. Five fixed approximate E cutoffs (1, 0.1, 0.01,
0.001, 0.0001) define all 90 endpoints. Exact binomial intervals are adjusted
over that complete denominator. The model-tail reference uses `1-exp(-E)` at
the smallest passing integer score, not a posterior orthology probability.
No prefilter, learned-profile search, biological grouping, parameter fitting
or benchmark scoring is performed. Source, native kernel, module origins and
scientific runtime packages are pinned; the [result](FROZEN_NULL_SCORE_RESULT_20261002.md)
preserves their full records. This is a supplementary diagnostic, not calibrated
significance or evolutionary simulation.

Comparators comprise OrthoFinder 3.1.5 full and its sequence-only MCL
checkpoint, OrthoMCL 1.4, SonicParanoid 2.0.9, ProteinOrtho 6.3.6, and
FastOMA 0.3.5. The checkpoint is a distinct output level, not another
phylogenetically finalized prediction. In the retained OrthoFinder full
run, finalized `Orthogroups.txt` reflects root hierarchical-group
postprocessing; its filename does not identify it as sequence-only.
FastOMA's supplied OrthoFinder tree is disclosed rather than treated as
independent tree inference. Native-output semantics and source records are
retained in the [comparison](PUBLICATION_COMPARISON_ORTHOMCL_COMPLETE_20260916.md)
and [OrthoBench protocol](ORTHOBENCH_UNCERTAINTY_PROTOCOL_20260916.md).
The v3 method is described by
[Emms et al. (2026)](https://doi.org/10.1038/s41592-026-03126-6), with a
[published Figure2 correction](https://doi.org/10.1038/s41592-026-03238-z).
This citation does not replace executable/version provenance for our runs.
The earlier orthogroup and phylogenetic methods are described by
[Emms and Kelly (2015)](https://doi.org/10.1186/s13059-015-0721-2) and
[Emms and Kelly (2019)](https://doi.org/10.1186/s13059-019-1832-y).
Other comparator references are
[Li et al. (2003), OrthoMCL](https://doi.org/10.1101/gr.1224503),
[Cosentino et al. (2024), SonicParanoid2](https://doi.org/10.1186/s13059-024-03298-4),
[Klemm et al. (2023), Proteinortho6](https://doi.org/10.3389/fbinf.2023.1322477),
and [Majidian et al. (2025), FastOMA](https://doi.org/10.1038/s41592-024-02552-8).
These method citations do not establish which optional modules or settings
ran in our experiments; retained execution records govern that attribution.

Companion-method references distinguish protein search
([DIAMOND](https://doi.org/10.1038/s41592-021-01101-x)), multiple alignment
([MAFFT](https://doi.org/10.1093/molbev/mst010) and
[FAMSA](https://doi.org/10.1038/srep33964)), tree inference
([FastTree](https://doi.org/10.1371/journal.pone.0009490) and
[FastME](https://doi.org/10.1093/molbev/msv150)), and protein-family clustering
([MCL](https://doi.org/10.1093/nar/30.7.1575)). These references describe method
lineages, not proof that every installed companion was invoked in every run.
Version resolution and actual commands are retained separately in the
[dependency review](PUBLICATION_DEPENDENCY_REFERENCES_20260918.md) and
[DGX companion-path audit](DGX_SCALING_MIGRATION_20260917.md).

For QfO, OrthoHMM high sensitivity and the OrthoFinder checkpoint contribute
group-derived cross-species pairs; OrthoHMM satellite_v2 and full OrthoFinder
contribute phylogenetically inferred pairs. SonicParanoid contributes native
species-pair relations, ProteinOrtho its native post-clustering graph, and
FastOMA native pairs. OrthoMCL contributes cross-species pairs derived from
its final MCL groups. Pre-MCL graph edges are retained only as a diagnostic.
These output differences are part of the practical pipeline comparison and
must not be interpreted as a matched search-engine ablation.

A complete historical FastOMA conversion audit validated 15,320,615 native
cross-species pairs against the 976,504-protein input universe and found no
duplicates. Independent sorting reproduced both the retained raw prediction
set and the 15,277,489-pair QfO-filtered set exactly; 43,126 pairs contained
identifiers absent from the historical mapping. This establishes conversion
integrity, not biological correctness or freedom from mapping-related bias,
and does not substitute for the corrected-release rerun.
[Conversion audit](FASTOMA_DISTINCT_PAIR_AUDIT_20260918.md).

The historical FastOMA OrthoXML declared 967,184 of the 976,504 input
proteins. Its 55,486 root HOGs referenced 588,873 proteins, of which 584,445
appeared in native pairs. The root-HOG table exactly matched XML membership,
and all native pairs joined known cross-species proteins within one root HOG.
These are native-output coverage counts, not reference-relative recall.
Identifier consistency does not establish why proteins were omitted or whether
each predicted relation is biologically correct.
[OrthoXML audit](FASTOMA_ORTHOXML_AUDIT_20260918.md).

### Development-Exposed Benchmarks

QfO and OrthoBench influenced development and are therefore not independent
confirmation sets. OrthoBench evaluates the complete retained 70-RefOG panel
with its low-certainty exclusions and audited weighted pair statistic.
The benchmark frameworks are described by
[Altenhoff et al. (2016)](https://doi.org/10.1038/nmeth.3830) and
[Emms and Kelly (2020)](https://doi.org/10.1093/gbe/evaa211), respectively.
QfO service updates are described by
[Altenhoff et al. (2020)](https://doi.org/10.1093/nar/gkaa308) and
[Nevers et al. (2022)](https://doi.org/10.1093/nar/gkac330), including the
2020 reference-proteome update and VGNC benchmark in the latter. These
papers do not replace retained release, input and scoring provenance.
Weighted counts divide each reference-family contribution by reference size
minus one; aggregate precision, recall, and F1 are computed from those
counts, not by averaging family F1 values.

We resampled RefOGs jointly across methods 20,000 times using NumPy PCG64
seed 20260916 and recomputed the statistic for each replicate. We report
paired percentile intervals and Bonferroni-adjusted intervals across two
OrthoHMM-versus-OrthoFinder contrasts and three metrics. The protocol was
recorded after historical aggregate results were known, before this
bootstrap; it is not preregistration of method selection. Family
exchangeability and residual cross-family dependence limit inference.
[Protocol](ORTHOBENCH_UNCERTAINTY_PROTOCOL_20260916.md).

The numerical and reporting implementations use
[NumPy](https://doi.org/10.1038/s41586-020-2649-2) for array/bootstrap operations,
[Biopython](https://doi.org/10.1093/bioinformatics/btp163) for sequence/tree
validation helpers, and [Matplotlib](https://doi.org/10.1109/MCSE.2007.55) for
plots. The [analysis-dependency review](PUBLICATION_NUMERIC_REFERENCES_20260918.md)
links those roles to source modules; per-run manifests determine executed
versions. Library citations do not validate statistical assumptions or plots.

The [SwissTree resource](https://www.expasy.org/resources/swisstree) and
[TreeFam resource paper](https://doi.org/10.1093/nar/gkj118) describe curated
gene-tree references; they do not authenticate our exact retained snapshots.
[FAS](https://doi.org/10.1093/bioinformatics/btad226) measures feature-architecture
similarity, not pairwise orthology F1. Its later method paper is resource
attribution, not proof of the implementation used for the QfO2020 archive.
The [ENZYME resource paper](https://doi.org/10.1093/nar/28.1.304) provides
enzyme-nomenclature background, not a citation for the QfO EC scoring formula
or evidence of the source release used for our historical annotations.
Source checks and machine-readable SwissTree/ENZYME citations are retained
in the [resource supplement](PUBLICATION_RESOURCE_REFERENCES_20260918.md).

The [VGNC resource paper](https://doi.org/10.1186/s13059-023-02957-2) describes
vertebrate gene nomenclature, while the QfO service protocol defines its
benchmark use. Gene Ontology is attributed to its
[foundational paper](https://doi.org/10.1038/75556); the later
[2026 knowledgebase update](https://doi.org/10.1093/nar/gkaf1292) is contextual
resource attribution, not the annotation release or scorer used in QfO2020.
Neither resource citation establishes historical snapshot identity or supplies
dependency-aware uncertainty for our functional endpoints.

For QfO we retain individual VGNC, SwissTrees, TreeFam-A, EC, GO, and FAS
endpoints, their native axes, and source provenance. The unweighted mean of
six project-selected summaries is secondary and is not an official QfO
score. Relation counts assessed by functional endpoints do not necessarily
equal total prediction coverage. Three Kingdoms is supplementary: its
BUSCO-reference pair statistic ignores false positives involving
non-reference genes and cannot establish proteome-wide orthology accuracy.
BUSCO's conserved-gene completeness framework
([Manni et al., 2021](https://doi.org/10.1093/molbev/msab199)) is distinct
from this project's BUSCO-reference pair statistic.
[Machine-readable comparison](publication_comparison_orthomcl_complete_20260916.json).

The [retained Three Kingdoms source audit](THREE_KINGDOMS_SOURCE_AUDIT_20260918.md)
identifies BUSCO5.8.2 and eukaryota_odb10 dated2024-01-08 (OrthoDB10.1).
Its 12 saved full tables reconstruct the scored reference byte-for-byte:
255groups,2,035genes and7,352pairs. Compressed downloads reproduce retained
raw FASTAs; eleven staged proteomes are byte-identical, while seven zebrafish
sequences differ only by removal of29 stop markers. None of those seven
belongs to the scored reference; indirect effects and historical per-tool
input identity are not established by that observation. The Xenopus download
URL uses a moving UniProt current_release path, so retained hashes are needed
and the URL alone is not a reproducible release identifier.

A subsequent [method-input audit](THREE_KINGDOMS_METHOD_INPUTS_20260918.md)
found that SonicParanoid's native snapshot matches the raw zebrafish FASTA,
not the stop-marker-stripped staged version. Five other retained checksum
manifests match all12 staged inputs; the older high-sensitivity metrics lack
per-file hashes. The historical supplementary table is therefore not presented
as a fully established identical-input cohort. A contemporary matched-staged-
input Sonic run has now completed with independently verified conversion
and scoring. The[updated supplementary table](three_kingdoms_comparison_matched_20260918/scores.md)
uses this new run and retains the historical Sonic result as a separate
diagnostic row. No causal effect of the input mismatch is inferred from
the difference between runs; other historical input-consumption limitations
remain unresolved.

For the separately recovered four-stage QfO replay, SwissTrees raw counts
were reconstructed using the frozen native scorer and reference. Each
one-direction reference relation contributes half a count before a prior
of one is added to each confusion category. Across18 reference families,
precision and recall are averaged separately before forming the project F1.
We used100000 shared paired family draws (PCG64seed20260919), recomputing
this statistic in each draw, with nominal95% and12-endpoint Bonferroni
percentile intervals for four contrasts and three metrics. The protocol
was fixed after point estimates were known but before interval calculation;
it is development-exposed follow-up, not independent confirmation. Disjoint
represented genes do not eliminate dependence from shared evolutionary
history or merged predictions. Other QfO challenges need separate uncertainty
analyses; these intervals do not cover the secondary six-metric mean.
[Protocol](QFO_SWISS_UNCERTAINTY_PROTOCOL_20260917.md).

### Prospective Validation And Ablations

YGOB combines curated homology with syntenic context
([Byrne and Wolfe, 2005](https://doi.org/10.1101/gr.3672305)); that original
resource description does not establish independence of our retained subset.

The frozen YGOB experiment retains 16 non-Saccharomyces species, 83,404
inference proteins, and 83,391 reference genes in 10,250 curated pillars.
Thirteen proteins from ambiguous duplicate-membership rows remain in
inference but are projected out of scoring. The endpoint is homolog-group
co-membership, including within-species pairs, not resolved orthology.
The primary contrast is satellite_v2 versus full OrthoFinder; high
sensitivity is secondary and the sequence checkpoint diagnostic. Its
20,000-replicate paired pillar bootstrap has seed 20260917 and six-metric
multiplicity handling. Native/source/input, command/conversion, independent
reference reconstruction and overlap checks passed before scoring. Direct
pair enumeration independently reproduced all four methods' TP/FP/FN counts.
[Frozen protocol](YGOB_VALIDATION_PROTOCOL_20260916.md).

On this frozen panel, satellite_v2 achieved F1 92.233654%, versus 92.318524%
for full OrthoFinder. The paired difference was -0.084870 percentage points
(nominal 95% interval [-0.487503, 0.312676]; six-endpoint Bonferroni interval
[-0.622528, 0.445222]). This does not establish superiority or equivalence.
Satellite_v2 had higher precision (+6.401035 points) and lower recall
(-6.914033 points), with both adjusted intervals excluding zero. High
sensitivity scored 82.038608% F1, below full OrthoFinder by 10.279916 points
(adjusted interval [-11.260924, -9.298064]). The diagnostic sequence-only
OrthoFinder checkpoint scored 85.572844%. All methods covered every reference
gene. No configurations were changed in response to these held-out outcomes.
[Frozen results](YGOB_FROZEN_RESULTS_20260916.md),
[machine-readable evidence](ygob_frozen_results_20260916.json).

[![Frozen YGOB scores and paired differences](figures_ygob_frozen_20260916/ygob_validation.png)](figures_ygob_frozen_20260916/ygob_validation.png "Full-resolution figure")

Figure: observed co-membership scores and paired OrthoHMM-minus-OrthoFinder
differences. Thick intervals are nominal 95%; thin intervals apply the frozen
six-endpoint Bonferroni adjustment. The checkpoint is diagnostic. All methods
cover every scored reference gene; this does not establish family independence.

This experiment tests novel-taxon transfer, not family-disjoint validation.
The completed label-independent homology screen found qualifying development
input hits for 71,714 of 83,404 proteins and 6,952 of 10,250 pillars.
Absence of a qualifying hit does not establish absence of homology.
Shared reference-resource limitations are documented separately.
[Screen](ygob_homology_screen_20260916.json),
[resource audit](YGOB_REFERENCE_RESOURCE_AUDIT_20260916.md).

Prospective component experiments cross profile-HMM expansion, candidate
expansion, and reconciliation in eight cells. Expansion-plus-reconciliation
cells retain their own membership constraints; independently inferred trees
are distinguished from supplied-tree diagnostics. A profile-expansion-off
arm still uses the HMM-centered initial search. A subsequent matched-recall
simulation control tests initial-search evidence under identical graph settings;
it does not isolate an overall advantage of HMMs on real benchmarks.
The OrthoBench, original-release QfO and corrected-release QfO factorials
are complete. Each QfO factorial has paired SwissTrees intervals across
18 families and 42 adjusted endpoints. The corrected full-comparator panel
is complete. Search-recall matching is now established on the declared
simulation panel only; real-data matching and matched computational effort
remain unestablished.
Original-release results are retained as development-exposed evidence, not
relabeled as corrected-release validation.
[Ablation protocol](PUBLICATION_ABLATION_PROTOCOL_20260916.md).

### Evolutionary Simulations And Runtime Admission

We used [Zombi](https://doi.org/10.1093/bioinformatics/btz710) at revision
`8db13ee4ba007f46c17f38586d31e5aa617c1647` and
[Pyvolve](https://doi.org/10.1371/journal.pone.0139047) 1.1.0 with the recorded
per-family seed adapter. These published simulator methods do not substitute
for local checks of event-derived truth and deterministic sequence generation.

Two separate panels each contain ten independent simulation seeds and seven
conditions: baseline, increased divergence, increased duplication/loss,
combined divergence and turnover, missing proteins, uneven taxon sampling,
and a taxon-count control. Native Zombi histories provide event-based
cross-species orthology truth; shared ancestral-family membership alone is
not treated as resolved orthology. Four configurations are evaluated on each
of the 70 datasets. The first panel uses fixed 300-residue sequences; a
prospectively specified second panel assigns each ancestral family a
deterministic seed-specific length between 100 and 500 residues. Descendants
retain that length, so this panel does not simulate within-family indels.
[Fixed protocol](PUBLICATION_SIMULATION_PROTOCOL_20260916.md),
[variable-length protocol](PUBLICATION_VARIABLE_LENGTH_PROTOCOL_20260916.md).

Initial OrthoHMM runs lacked a required native alignment library; profile
construction exceptions were silently caught and no profiles were built.
Those runs are invalid runtime diagnostics, not estimates of the intended
method. Corrected runs retain the frozen algorithm and verify compiled
libraries and an actual profile-construction probe before and after execution.
Valid original comparator outputs are reused with separate provenance.
Admission requires native completion and output validation, including finite
OrthoFinder graph weights; a zero process exit code alone is insufficient.
[Runtime correction](SIMULATION_RUNTIME_CORRECTION_PROTOCOL_20260916.md).

Within each panel, we bootstrap paired successful seeds 20,000 times and
recompute the mean seed-level statistic. Fourteen primary F1 contrasts use
Bonferroni-adjusted intervals; precision and recall are exploratory. Failed
runs are reported separately, not assigned zero accuracy. Complete-case
contrasts condition on joint success, and available-case table means cannot
be subtracted when they summarize different seeds. The two panels are not
pooled. [Fixed results](SIMULATION_FIXED_NATIVE_RESULTS_20260916.md),
[variable results](SIMULATION_VARIABLE_NATIVE_RESULTS_20260916.md).

### Simulation Species-Tree Controls

For each of the70 variable-length datasets, the frozen satellite_v2 and full
OrthoFinder pipelines were rerun with three prespecified supplied trees: the
induced generating topology and deterministic rooted NNI perturbations at
clade distances2 and4. Branch lengths travel with subtrees; these are topology
stress tests, not sampled posterior uncertainty. Generating trees are oracle
diagnostics, not independently inferred predictions or guaranteed accuracy
upper bounds. Non-tree settings and input sequences remain frozen. All132
available unchanged-inferred-tree mode controls reproduced native pairs and
retained upstream files;199 downstream partition checks also agreed. Eight
unavailable original controls were retained, not excluded from subsequent runs.

Independent admission checked all420 supplied runs, requested topology
retention, native output validity and source/input provenance. Cross-arm
retained-artifact comparisons preceded truth scoring. All successful original
inferred scores were recomputed exactly. For each condition and method we
compared generating minus inferred, NNI1 minus generating, and NNI2 minus
generating for F1, precision and recall. All126 endpoints are exploratory,
with20,000 paired-seed resamples and Bonferroni tail adjustment at family
alpha0.05. The statistic is the mean paired per-seed difference, not a pooled
pair-count ratio. Failed arms remain explicit without accuracy imputation.
Small seed counts and bootstrap-tail resolution limit interval calibration.
[Protocol](SIMULATION_TREE_CONTROL_PROTOCOL_20260917.md),
[complete results](SIMULATION_TREE_ROBUSTNESS_RESULTS_20260917.md).

## Results

### Synthetic Null Tails Expose A Significance Limitation

For the frozen width-64 `E < 1e-4` gate, ordinary-background hits were 0/1/0
of 10,000 pairs at lengths 50/150/400; uniform-residue hits were 1/5/3.
Full-matrix hits were 0/2/0 and 1/7/12, respectively. Half-background-plus-half-
glutamine sampling passed 8,983/10,000 pairs at length 50 and all 10,000 at
each longer length in both bands. The adjusted exact intervals for these
glutamine fractions are [88.7484%, 90.8453%] and [99.9181%, 100%] for both
longer lengths. Total glutamine probability exceeds 0.5 because the remaining
background mass also contains glutamine. This strong synthetic regime is not
a measured proteome prevalence or validated evolutionary generator.

![All prespecified synthetic null-score tails, including adjusted intervals and zero-hit upper limits.](figures_frozen_null_scores_20261002_v2/frozen_null_scores.png)

Figure: all 90 planned endpoints for nine composition/length cells, with
10,000 independently drawn pairs per cell. Full/width-64 glyphs are slightly
offset horizontally; exact cutoffs are retained in the plotted TSV. Whiskers
are 90-endpoint Bonferroni-adjusted exact binomial intervals. Downward triangles
show upper bounds for zero hits, not positive observed fractions. The dashed
Poisson-model reference is a diagnostic hypothesis for the fixed formula,
not proof of its applicability to the recurrence. The short-sequence fallback
produces identical band scores at length 50. The [complete result](FROZEN_NULL_SCORE_RESULT_20261002.md)
and [figure values](figures_frozen_null_scores_20261002_v2/plotted_values.tsv)
retain all cutoffs and paired band losses, not selected favorable outcomes.

The independent audit regenerated all 180 sequence digests and recomputed all
90 counts/intervals and paired score changes. Reference Python matched the
first pair of every seed cell in both bands: 180 sparse score checks, not
all-native-score equivalence. Interval recomputation used beta quantiles
instead of the producer's binomial-result API, still within SciPy. The first
audit attempt failed before reading results because of its import path; only
that path was corrected, and no native experiment was repeated. Retained
scores and public readback tests preserve numerical reproduction without
depending on the local one-off audit files.

This establishes a conditional limitation of the approximate significance
formula, not real-data orthology false-positive rates, a causal explanation of
benchmark differences or superiority over OrthoFinder. Zero-hit adjusted
upper bounds are approximately 0.00081853, above the production cutoff;
ordinary-background samples therefore do not certify rare-tail calibration.
No new constants, bands, thresholds or defaults are fitted or promoted.

### OrthoBench Shows A Precision-Recall Tradeoff

OrthoHMM satellite_v2 achieved weighted F1 74.106074%, compared with
72.736480% for full OrthoFinder and 70.358998% for high sensitivity.
Satellite_v2 precision was 81.770454% and recall 67.755336%; full
OrthoFinder precision was 66.065103% and recall 80.906577%.
The exploratory eight-method extension uses 100,000 paired RefOG resamples
(PCG64 seed 20260928), recomputes weighted counts and scores in each draw,
and adjusts across all 21 contrasts: seven alternatives versus full OrthoFinder
for F1, precision and recall. The satellite_v2 F1 difference was +1.370
percentage points, with nominal 95% interval [-4.482, 8.051] and adjusted
interval [-7.281, 12.166]. These intervals do not establish an F1 advantage.
Its precision difference was +15.705 points [1.175, 30.634] and recall
difference -13.151 [-26.947, -0.609] after adjustment. High-sensitivity
precision was +12.884 [-0.895, 24.222], no longer excluding zero under the
broader correction. Its recall deficit remains: -17.452 [-32.103, -3.845].
These are development-exposed comparisons, not selection-adjusted confirmation.
Approximate percentile intervals assume exchangeable families; shared genes,
histories and cross-family prediction errors can violate that assumption.
[Complete results and independent arithmetic check](OB_COMPLETE_UNCERTAINTY_RESULT_20260928.md).
The [complete interval figure](figures_ob_complete_uncertainty_20260928/ob_complete_uncertainty.pdf)
retains all 21 endpoints, nominal and adjusted intervals, and a fixed method
order. Its [relocated reproduction](OB_INTERVAL_BUNDLE_20260929.md) reproduces
PNG and plotted-value bytes; this is plotting portability on the same host,
not independent statistical validation or native inference reproduction.

The original three-method analysis remains available with its separate
20,000 draws, seed 20260916 and six-endpoint correction. Its satellite_v2
F1 intervals were [-4.504, 7.917] nominal and [-6.290, 10.627] adjusted.
Those narrower historical intervals must not be substituted into the complete
21-endpoint comparison. [Historical uncertainty results](ORTHOBENCH_UNCERTAINTY_20260916.md).

Across individual RefOGs, satellite_v2 had 23 F1 wins, 10 ties, and 37
losses relative to full OrthoFinder. High sensitivity had 20 wins, 11 ties,
and 39 losses. These descriptive counts need not rank methods identically
to the weighted aggregate statistic and do not substitute for it.
[Per-family analysis](orthobench_paired_uncertainty_20260916.json).

### OrthoBench Direct Hits And Grouping Outcomes

The [joint search/stage trace](OB_SEARCH_STAGE_JOINT_COUNTS_20260918.md)
covers all70 retained reference families. Of40733 descriptive pair
memberships,24333 lack a direct cached hit in either direction. Final root
HOGs nevertheless group8465 of these together, while1971 pairs with at least
one retained hit remain separated. Candidate-to-root processing separates
1575 previously grouped reference pairs and gains none. These observations
show why direct-hit presence alone cannot explain final membership. They do
not identify rejected RBNH edges, prefilter-versus-scoring rejection, or the
individual effects of tree inference, reconciliation and constraints.
Counts include low-certainty and within-species pairs and are not the
official weighted recall statistic or independent biological validation.

A subsequent [frozen initial-graph reconstruction](OB_INITIAL_EDGE_TRACE_20260918.md)
separates retained hits from accepted graph edges. Among the1,971 hit-supported
pair memberships separated in final root groups,505 had an initial edge,
1,453 had hit scores below both endpoint thresholds, and13 had no finite
endpoint threshold. Conversely,4,201 hit-supported memberships without an
initial edge were grouped together in final root groups. These descriptive
counts passed an independent pair-table and arithmetic audit, but the audit
does not independently reconstruct the native graph. Initial direct edges
are neither necessary nor sufficient for final co-membership; indirect paths,
subsequent refinement and partitioning require separate causal investigation.

A separately frozen CPU [search-decision diagnostic](OB_SEARCH_DECISION_RESULT_20260918.md)
observed all81,466 directed reference-family pairs across144 species
directions. It accepted31,479 pairs, excluded48,368 at the prefilter and
scored1,619 without reaching E<1e-4. Accepted-hit presence matched the
historical trace for every watched pair. Independent reconstruction from
saved raw candidate arrays verified every decision and table row. This
localizes rejection in the observed run but does not authenticate historical
execution or prove numerical score equivalence. The descriptive pair set
includes within-species and low-certainty members; these counts are not
official recall, evidence that excluded pairs are true orthologs, or a causal
explanation of final grouping errors. Benchmark predictions were not changed.

A subsequent [forced-candidate diagnostic](OB_FORCED_CANDIDATE_PROTOCOL_20260926.md)
scored the same 81,466 pairs with the frozen HMM engine while overriding
only candidate selection and retaining full target databases for E-values.
Of the 48,368 previously excluded pairs, 30,496 passed E<1e-4 and 17,872
did not. All 33,098 previously scored pairs retained exactly identical
scores, E-values and decisions; the 1,619 prior significance rejections
remained rejected. An [independent raw-output audit](ob_forced_candidates_audit_20260926.json)
verified the pair universe, numerical agreement and transition counts.
Thus candidate selection prevented significant HMM hits for 30,496 watched
directed pairs. Reference labels selected the forced pairs, so this is
mechanistic evidence, not unbiased sensitivity, proof of true orthology,
matched DIAMOND sensitivity or a downstream precision/F1 improvement.
No broader-prefilter grouping run is evaluated by this diagnostic.

![Forced scoring of reference-conditioned OrthoBench pairs, stratified by their original search decision.](figures_forced_candidates_20260926/forced_candidates.png)

The stacked counts show unchanged prior acceptances and significance
rejections, and the split of prefilter-excluded pairs after forced scoring.
These are directed search-pair counts, not independent ortholog observations
or confidence intervals. [Vector PDF](figures_forced_candidates_20260926/forced_candidates.pdf)
and [figure provenance](figures_forced_candidates_20260926/manifest.json).

Joining these decisions to the retained final-root-group trace found8,386
pairs excluded by the prefilter in both directions that were nonetheless
grouped together, and15,129 such pairs that remained separated. Pairs scored
but not significant in both directions contributed32 grouped and218
separated observations; mixed prefilter/scoring rejection contributed47
and521. These recover the earlier8,465 grouped and15,868 separated pairs
without any accepted direct hit. The [complete family-level join](OB_SEARCH_GROUPING_JOIN_20260918.md)
also retains the1,971 separated pairs with an accepted direct hit. These
descriptive patterns reinforce that direct search acceptance is neither
necessary nor sufficient for final co-membership, not that prefilter
exclusions are harmless or causally responsible for the observed F1 deficit.

### QfO Results Vary Across Endpoints

The following original-input historical comparison and its endpoint figure
are not the primary corrected-release results. The
[current corrected eight-method table](qfo_corrected_comparison_20260926_v7/scores.md)
and corrected endpoint panel below retain the primary QfO values separately.
On the original-input historical release, secondary QfO means were 0.782071 for full OrthoFinder, 0.748243 for
satellite_v2, and 0.682548 for high sensitivity. Full OrthoFinder had higher
VGNC, SwissTrees, and TreeFam-A F summaries than either OrthoHMM mode.
Satellite_v2 had higher EC, GO, and FAS similarity summaries than full
OrthoFinder. Because these functional summaries assess different predicted
relation sets, higher similarity alone does not establish higher overall
orthology accuracy. The six native endpoint panels retain their assessed
relation counts or precision-recall axes.
[Comparison](PUBLICATION_COMPARISON_ORTHOMCL_COMPLETE_20260916.md),
[endpoint figure](figures_accuracy_orthomcl_complete_20260916/qfo_endpoints.png).

An audit of saved FAS samples reproduced all eight comparator means and
native standard errors, as well as four recovered-stage results, within
1e-12. The scored fraction of reported eligible pairs ranged from 0.0067%
to 31.3477%; the eligible count is not the total prediction count. Native
code subsamples without setting a shuffle seed, and its pair-based SEM
does not account for shared proteins or families. These SEMs are not
dependence-aware uncertainty for method contrasts. The audit validates
saved-sample arithmetic, not sampling representativeness or underlying
feature-score correctness. [FAS sample audit](QFO_FAS_SAMPLE_AUDIT_20260917.md).

For the later corrected v7 comparison, the
[requested-score attrition audit](QFO_FAS_SAMPLE_ATTRITION_20260928.md)
reconciled all eight saved samples with their native logged strata. Every
method requested 9,000 new scores. Shortfalls were 7 for high-sensitivity
OrthoHMM, 27 for satellite_v2, 25 for full OrthoFinder, 36 for its sequence-only
checkpoint, 6 for SonicParanoid, 1 for ProteinOrtho, 49 for FastOMA and 1,252
for recovered OrthoMCL. All requested precomputed scores were retained.
These FAS shortfalls are distinct from sequence-specific OrthoMCL BLAST failures.

If S is the sum of n saved scores and d requested values are omitted, assuming
each omitted value lies in [0,1] bounds the intended-sample mean by
[S/(n+d), (S+d)/(n+d)]. OrthoMCL's bounds are 0.724872-0.736975, compared with
its saved mean of 0.733752. These deterministic completion bounds condition
on the intended sample; they do not cover unsampled eligible pairs, identify
a corrected population mean or substitute for confidence intervals. Completing
only the omitted sampled values cannot reverse either OrthoHMM-versus-full-
OrthoFinder FAS sample-mean ordering, but does not establish an advantage
beyond those samples.

A separate [stratum-weight decomposition](QFO_FAS_STRATUM_WEIGHT_RESULT_20261001.md)
reproduces all eight native means without rescoring. The intended mixture is
approximately proportional to eligible precomputed/new populations, but
omitting only newly calculated values changes its realized weights. OrthoMCL's
precomputed share rises from 91.300061% intended to 92.418564% saved. Holding
the observed stratum means fixed, rounding and attrition together change its
mean by +0.001318947 relative to a population-weighted mixture of those same
observed means; the corresponding full-OrthoFinder change is +0.000085894.
This is a numerical diagnostic, not a population estimate or correction of
the benchmark. Omitted values may also change the new-score stratum mean;
historical selection and protein/family dependence remain unresolved. Native
scores, earlier completion bounds and the lack of paired FAS intervals remain.

A [controlled probe](QFO_FAS_OMISSION_MECHANISM_20260928.md) inside the retained
greedyFAS 1.18.7 container verified that proteins exceeding the configured
`10**15` feature-path limit produce NA values, which the QfO loader omits.
Native graph calculations on [all 78 retained annotation files](FAS_NATIVE_ANNOTATION_PATH_PANEL_20260928.md)
identified 1,143 above-limit proteins among 984,137 unique identifiers. The
[saved-sample exposure audit](FAS_SAVED_COMPLEXITY_EXPOSURE_20260928.md)
found no above-limit endpoint in saved newly calculated pairs for any method.
All methods nevertheless retained such endpoints in precomputed pairs,
including 4,122 pairs for OrthoMCL. Precomputed values are not invalidated by
the current new-scoring cutoff.

Streaming all 59,962,787 frozen lookup entries independently confirmed
membership and values for 3,023,018 unique saved precomputed pairs and absence
of valid precomputed values for 70,528 unique saved new-score pairs. Native
last-valid canonical overwrite semantics were reproduced. This verifies
selected saved-score provenance, not every unused score or FAS algorithm
correctness. The architecture flags and absence among saved new pairs are
consistent with an omission mechanism, but neither identify the historically
omitted sample nor attribute all shortfalls to that mechanism. Full eligible-pair
exposure to the complexity cutoff, selection bias and family-aware comparison
uncertainty remain open.

The [completed eight-method eligible-population audit](QFO_FAS_POPULATION_COMPLETED_22383.md)
retains the original timeout, reuses six unchanged recounts and newly scans
FastOMA/OrthoMCL. All native logged populations and saved-sample lookup checks
match. Pairs absent from the valid precomputed lookup comprise 23.58% of
high-sensitivity OrthoHMM's eligible set, 5.13% of satellite_v2, 16.86% of full
OrthoFinder and 82.05% of the sequence-only checkpoint. Let S be the sum of
all valid precomputed scores over P eligible pairs and M be the number of
eligible pairs without a lookup score. Assuming hypothetical missing values
in [0,1] gives conservative population outer bounds [S/(P+M), (S+M)/(P+M)].
Some lookup-missing pairs were newly scored in native samples; these values
are not used to tighten the bounds. This calculation is separate from the
earlier intended-sample attrition bounds and from native FAS estimation.
Satellite_v2's range is 0.733966-0.785282, versus 0.605946-0.774511 for full
OrthoFinder; overlap prevents establishing a full-eligible-set advantage by
these bounds. Independent aggregate arithmetic and exact reuse/source/input
bindings pass, but no large joins or lookup scores are independently repeated.
The [complete table](qfo_fas_population_completed_22383/scores.md) preserves
all eight methods without changing the native scores or admitting confidence
intervals, sampling representativeness or overall accuracy rankings.

For GO and EC, all 24 historical-comparator/recovered-stage raw counts,
means and native uncertainty values were consistent with the retained
scorers within six-decimal raw serialization bounds. Inspection and execution
of the pinned Darwin statistics implementation established that GO/EC
`stderr` values are Student-t 95% confidence half-widths, whereas FAS reports
one SEM. These native quantities are not interchangeable and neither supplies
family-aware paired method uncertainty. Every audited GO/EC result reuses
proteins across scored pairs. [GO/EC audit](QFO_GO_EC_ARITHMETIC_AUDIT_20260917.md).

A subsequent [corrected all-method pair audit](QFO_SCORED_PAIR_PANEL_20260927.md)
compared all 28 method pairs separately for GO and EC. Across all 56
comparisons, shared protein pairs had identical retained six-decimal scores.
All 16 raw counts and rounded means matched the admitted endpoints within
serialization tolerance. Assessed counts nevertheless differed markedly:
phylogenetic OrthoHMM scored 84,211 GO and 117,460 EC pairs, versus 163,557
and 175,361 for full OrthoFinder. Thus mean differences at this retained
precision reflect which eligible pairs are predicted and their denominators,
not different functional scores for shared pairs. Restricting comparison to
the intersection would change the endpoint and erase these differences.
This is descriptive arithmetic, not causal attribution, proof of identical
unavailable full-precision scores or a solution to family-aware uncertainty.
The raw tables agree with admitted aggregate counts and means. An initial
direct-list search found no raw-table hashes in the admissions themselves;
a [subsequent transitive check](QFO_SCORED_PAIR_TRANSITIVE_BINDING_20260927.md)
followed their pinned execution reports and verified all 16 raw tables against
historical output hashes. All 56 comparison objects remained unchanged. This
establishes the panel's raw-byte binding, not complete workflow provenance or
statistical validity.

The independently admitted recovered replay is reported separately from
these historical method rows. Its profile branch had SwissTrees F1
differences of-0.003706 before and-0.003716 after sequence-based refinement
(raw0-to1 units). The corresponding adjusted intervals were
[-0.020824,0.003397] and[-0.020829,0.003347]. Across all four fixed stage
contrasts and three metrics, every adjusted interval included zero; this
establishes neither a benefit nor equivalence. Only CASP and GH14 changed
under profile-branch processing (one family F1 gain, one loss,16 ties),
while sequence-based refinement changed only NOX (one loss,17 ties).
These are exhaustive descriptive family effects, not selected biological
success stories or mechanistic attribution. The profile branch includes
downstream graph/assignment responses; sequence refinement is not
phylogenetic reconciliation.
[Stage results](QFO_RECOVERED_STAGE_RESULTS_20260917.md),
[paired intervals](QFO_SWISS_INTERVALS_20260917.md).

On the original-release inputs, OrthoMCL final-group scoring completed
successfully, with all six endpoint
tasks and consolidation exiting zero. Its secondary mean was 0.705177.
The earlier pre-clustering diagnostic mean, 0.724414, is not the final-group
assessment and is excluded from the principal comparison. The run contained
53 sequence-specific BLAST failures among 976,504 proteins; all 53 were
absent from final groups. Direct-reference exposure was absent for VGNC,
SwissTrees, TreeFam-A, and EC, but present for four experimentally annotated
GO proteins; 46 failed proteins had nonempty FAS features. These observations
do not bound indirect clustering effects or establish a negligible score
impact. This historical baseline is retained with failures disclosed; neither
its scores nor its failure count substitute for the corrected-release run.
[Failure-impact audit](ORTHOMCL_FAILURE_IMPACT_20260916.md).

### Conserved-Family Recovery Remains A Weakness

Three Kingdoms BUSCO-reference F1 was 0.872133 for satellite_v2 and
0.826309 for high sensitivity, compared with 0.988582 for full OrthoFinder,
0.989451 for its sequence checkpoint, and 0.991276 for the contemporary
matched-input SonicParanoid run (precision0.993443, recall0.989119;
7272TP,48FP,80FN). Historical Sonic F1=0.990794 remains a diagnostic result
with a known input mismatch. All values measure reference-gene group
co-membership, not genome-wide orthology or native pair prediction accuracy.
The checkpoint's small advantage over full OrthoFinder on this restricted
target does not establish that phylogenetic inference is generally harmful.
Mechanistic explanations require error tracing and controlled ablations.
[Recounted comparison with run/input labels](three_kingdoms_comparison_matched_20260918/scores.md).

![Current retained OrthoBench and supplementary Three Kingdoms group recovery for all eight methods.](figures_current_accuracy_overview_20261002_v2/current_accuracy_overview.png)

Figure: OrthoBench weighted precision/recall and BUSCO-reference pair F1 use
the unchanged current score table. The new overview selects the contemporary
matched-input SonicParanoid result, unlike the older historical overview.
All other Three Kingdoms values are unchanged apart from floating-point
roundoff. This is a presentation reconciliation, not new method improvement
or native inference. It is not a newly matched eight-tool experiment. BUSCO projection
includes within-species pairs and excludes non-reference-gene errors;
historical input-consumption gaps remain. No cross-dataset mean, universal
ranking or controlled efficiency follows. The OrthoFinder sequence row is a
pre-phylogeny MCL diagnostic, and FastOMA uses supplied-tree configurations.
[Figure audit and vector PDF](CURRENT_ACCURACY_OVERVIEW_20261002.md) and
[current exact score table](current_benchmark_scores_20260926_v2/scores.tsv).
QfO is not plotted in this overview; its separate corrected six-panel figure
retains all 48 method/endpoint points with their distinct axes and relation sets.

### Historical Components Provide Preliminary Evidence

Verified historical OrthoBench partitions gave F1 66.279051% after
multipass grouping, 69.763388% with cluster refinement, 66.825390% with
profile expansion alone, and 70.358998% with both. The descriptive increment
from profile expansion after refinement was +0.595610 percentage points.
The final replay partition was byte-identical to the corrected historical
fresh output. These are historical component observations without paired
intervals, not a complete current-source factorial or HMM-free control.
[Historical audit](HISTORICAL_PROFILE_ABLATION_20260916.md).

### Corrected Simulations Do Not Establish An OrthoHMM Advantage

In the fixed-length stress panel, high sensitivity completed all 70 datasets
and satellite_v2 completed 64. Six satellite_v2 failures persisted because
species-tree inference lacked connected single-copy taxon coverage. No full
OrthoFinder or parent-gated checkpoint output passed native admission, so
this panel provides no admitted paired comparison with OrthoFinder. Native
normalization diagnostics reproduced degenerate length fitting and nonfinite
scores; competitor failure is not evidence of an OrthoHMM accuracy advantage.
[Fixed interpretation](SIMULATION_FIXED_NATIVE_INTERPRETATION_20260916.md),
[native failure audit](SIMULATION_NATIVE_FAILURE_AUDIT_20260916.md).

In the variable-length panel, high sensitivity, satellite_v2, and full
OrthoFinder passed admission on 70, 67, and 65 datasets, respectively. Full
OrthoFinder led every paired condition-mean F1 comparison against either
OrthoHMM mode. Adjusted intervals excluded zero below OrthoFinder for all
seven high-sensitivity contrasts and four satellite_v2 contrasts; satellite_v2
turnover, missing-data, and uneven-sampling intervals included zero. Baseline
satellite_v2 and full OrthoFinder mean F1 were 99.46% and 99.94%. Satellite_v2
paired deficits were 11.74 percentage points under divergence (five paired
seeds) and 12.28 points under combined divergence and turnover (eight seeds).
Lower recall was the principal observed deficit, but its causal processing
stage has not yet been established.
[Variable interpretation](SIMULATION_VARIABLE_NATIVE_INTERPRETATION_20260916.md).

Three variable-panel satellite_v2 failures again involved species-tree
coverage. Five divergent OrthoFinder runs had nonfinite graph weights.
Reconstruction of native normalization across all ten divergent seeds
reproduced seven nonfinite within-species matrices in exactly those five
failed seeds. Each affected fit had two non-self hits at one length product;
the rank-deficient fit produced extreme intercepts and scale-factor overflow.
The proteomes themselves had heterogeneous lengths. This local failure does
not imply that every rank-deficient fit fails, and no competitor repair or
post-hoc exclusion of additional finite runs was applied.
[Normalization audit](ORTHOFINDER_VARIABLE_NORMALIZATION_AUDIT_20260916.md).

All corrected OrthoHMM runs constructed profiles, but neither simulation
panel added profile-expansion edges. These panels therefore do not demonstrate
an accuracy contribution from multi-sequence profile expansion, although the
initial HMM-based search remains present. They are not HMM-free controls.
Synthetic sequence evolution, limited seed counts, conditional comparisons,
and absent realistic domain architecture constrain extrapolation to proteomes.

The [variable-length figure](figures_simulation_variable_native_v2_20260916/simulation_evidence.png)
shows admitted-run counts beside paired F1 effects and nominal/adjusted
intervals. The [fixed-length figure](figures_simulation_fixed_native_v2_20260916/simulation_evidence.png)
explicitly shows the absence of admitted comparator contrasts. Both are
generated from the corrected machine-readable results without imputing failures;
PDF/SVG versions and source-hash manifests accompany the PNGs.

### Stronger Tree Perturbations Reduce Simulation Accuracy

All210 supplied-tree OrthoHMM runs passed native admission, compared with195
of210 OrthoFinder runs. The15 OrthoFinder failures were the same five divergent
datasets under each supplied tree, rejected for nonfinite upstream graph
weights. Supplying a tree did not repair that problem. The three original
OrthoHMM inferred-tree failures completed under all supplied topologies;
their missing inferred accuracy cannot be recovered from this observation.
The complete analysis contains537 scores and23 failures across560 arms.

Generating-minus-inferred mean F1 changes ranged0.000 to0.217 percentage
points for OrthoHMM and-0.005 to0.160 for OrthoFinder. Every adjusted interval
for these comparisons included zero. NNI2-minus-generating F1 and recall
intervals excluded zero below it in four OrthoHMM conditions (turnover,
divergent turnover, uneven taxa and taxon-count control) and two OrthoFinder
conditions (uneven taxa and taxon-count control). These12 endpoints were the
only adjusted intervals excluding zero; no precision interval did. This
establishes a bounded sensitivity observation, not comparative superiority,
biological equivalence, or robustness to arbitrary species-tree errors.

Of420 upstream-artifact contrasts,400 were equivalent,18 unavailable and two
different. Both differences involved OrthoFinder divergent seed20261106,
with changed OG0000004 alignments and raw gene trees. They remain in the
analysis and preclude strict tree-only causal attribution for the affected
comparisons. The comparison requires joint success: OrthoFinder uses five
divergent seeds and ten elsewhere; OrthoHMM generating-minus-inferred uses
nine divergent and eight divergent-turnover seeds, with ten for other
comparisons. Failure-conditioned estimates may be biased.
[Full records and limitations](SIMULATION_TREE_ROBUSTNESS_RESULTS_20260917.md).

[![All simulation species-tree effects](figures_simulation_tree_robustness_20260917/simulation_tree_robustness.png)](figures_simulation_tree_robustness_20260917/simulation_tree_robustness.png "Full-resolution figure")

Figure: all126 exploratory F1, precision and recall endpoints across seven
conditions, two methods and three tree contrasts. Points are paired-seed mean
differences; thick intervals are nominal95% and thin intervals use Bonferroni
adjustment over126 endpoints. Axes share scales down each contrast column.
No best-tree selection or failed-score imputation was performed. The figure
is generated from the complete verified summary with source/output hashes;
PDF and SVG versions accompany the PNG.

### Controlled Components Show A Candidate-Precision Tradeoff

The completed eight-cell OrthoBench factorial reproduced full-pipeline F1
74.106074%. Reconciliation improved F1 by 2.942-6.899 percentage points across
four matched settings; all four multiplicity-adjusted intervals excluded zero
above it. Broader candidates increased recall and reduced precision, with
adjusted intervals excluding zero in all four settings. Their observed F1
effect changed from about -3.1 points without reconciliation to +0.697/+0.795
with reconciliation, but every adjusted candidate-expansion F1 interval
included zero. Profile expansion added 0.568-0.704 observed F1 points;
all adjusted profile-expansion intervals included zero. These contrasts do
not remove the initial HMM search and do not establish a total HMM advantage.

All cells passed output/provenance gates and official-score crosschecks.
Four batch failures caused by postflight working-directory-dependent package
discovery were retained and separately recovered; native inference succeeded.
Shared-node cached reconciliation costs are not end-to-end timings. The
factorial remains development-exposed and supplies no new direct OrthoFinder
comparison. [Results and interpretation](ORTHOBENCH_FACTORIAL_INTERPRETATION_20260916.md).

A separate [full-native uncertainty binding](NATIVE_FACTORIAL_UNCERTAINTY_BINDING_20261005_V4.md)
currently links six terminal-scored cells to that retained analysis. All420
RefOG records, including metadata, exactly match; the six supported contrasts
reuse the original20,000 paired draws and36-endpoint adjustment. With candidate
expansion off and reconciliation on, P1C0R1 minusP0C0R1 gives+0.606368 F1
percentage points, adjusted percentile interval[-1.211436,4.520970], with
four family wins,61 ties and five losses. This interval includes zero.
With candidate expansion on and reconciliation off, P1C1R0 minusP0C1R0
gives+0.567966 F1 percentage points, adjusted interval[-1.113209,4.290615],
with six family wins,59 ties and five losses. All nominal and adjusted
F1/precision/recall intervals for this new contrast span zero. All four
cells retain initial HMM search, so this is a conditional downstream
profile effect, not a total HMM advantage, resolved-pair truth or independent
confirmation. Six native contrasts remain unavailable and are not imputed;
the failed22427 wrapper's scientific recovery remains failed timing. This
binding does not replace the complete retained eight-cell analysis or
establish native completion for the remaining identities.

### First Fresh Native QfO Ablation

The first fresh native QfO configuration, P0C0R0, now has independently
admitted scores. Native inference22435, pair conversion22439, assessment22441
and admission22442 completed successfully. The admission checked 3,975
declared records and all 15 fresh assessment tasks. Initial high-sensitivity
HMM search remains enabled; downstream profile expansion, candidate
expansion and reconciliation are disabled. This is not a non-HMM control.

| Endpoint | Statistic | Native Score |
| --- | --- | ---: |
| VGNC | F1 | 0.6668335335736216 |
| SwissTrees | F1 | 0.6891839606644314 |
| TreeFam-A | F1 | 0.6054035649224192 |
| GO | Schlicker similarity | 0.47211905 |
| EC | Schlicker similarity | 0.93211406 |
| FAS | FAS similarity | 0.7749447305326528 |
| Project-defined secondary mean | Mean of six endpoints, not official QfO F1 | 0.6900998166155209 |

Native precision/recall are 0.5551202978274157/0.8348374697083647 for VGNC,
0.64394009/0.74126605 for SwissTrees and 0.79224541/0.48987278 for TreeFam-A.
Predictions comprise 9,009,082 cross-species group-derived clique pairs,
with zero mapping loss. Of 984,137 input accessions across 78 proteomes,
546,450 occur in at least one relation: all-input relation coverage is
0.555258058583307, not reference coverage or accuracy. R-on configurations
instead submit native phylogenetically inferred pairs.

The raw FAS sample contains 38,205 pairs and 66,678 proteins, including
8,506 proteins appearing in multiple sampled pairs. The 9,000 cap applies
to newly computed missing pairs, not the entire mixed/precomputed sample.
Native FAS SEM is pair-IID, not a paired-family confidence interval;
unseeded sampling and eligible-population/missing-score limitations persist.
At this first-admission checkpoint, only one of seven fresh native QfO identities has supplied scores; the other
six remain unavailable, not zero. No cached result or its family intervals
is substituted. This development-exposed result establishes neither
historical partition equivalence, independent generalization, a total HMM
effect nor superiority over OrthoFinder. It does not replace the retained
eight-cell cached factorial or the earlier comparator table.
[Validated result and limits](NATIVE_QFO_SCORE_RESULT_22442.md),
[generated native score table](native_qfo_scores_20261005_v1/scores.md),
[original admission](native_qfo_assessment_admission_22442.json),
[independent content readback](native_qfo_score_readback_22442.json).

A subsequent [native SwissTrees count audit](NATIVE_QFO_SWISS_FAMILY_COUNTS_20261005.md)
reads the actual raw output: all 18 family records, including confusion
counts, represented genes and prior-adjusted statistics, match the retained
corrected P0C0R0 cell. Separate parser/rational readback also verifies all
10,765 scored SwissTrees reference-pair labels exactly match. Count-derived
full-precision F1 is 0.689183963152562; the native decimal endpoint above
remains unchanged. These bounded checks do not establish whole-partition or
other-endpoint equivalence. No historical interval is attached, new bootstrap
draw made or missing native contrast imputed; other QfO uncertainty remains open.

Conversion, scoring and admission are separate from matched inference timing.
Timings are observed shared-Threadripper measurements: competing analyses
may affect CPU, memory bandwidth and I/O by an unknown, tool-dependent
amount. Matching resource limits does not establish isolated performance.
The existing rc4 archive and reviewed PDF predate this partial native result;
final package integration and broader publication requirements remain open.

### Second Native QfO Cell And Conditional Reconciliation Contrast

Subsequently, native P0C0R1 has independent scientific admission 22449 after
assessment 22448. The original 22437 timing remains failed and ineligible;
recovering intact predictions does not repair its resource measurements.
At the two-cell checkpoint, the combined native snapshot had two admitted cells and five
unavailable rows. None is replaced with a cached cell or a zero score.

| Endpoint | Statistic | P0C0R0 | P0C0R1 |
| --- | --- | ---: | ---: |
| VGNC | F1 | 0.6668335336 | 0.8981845793 |
| SwissTrees | F1 | 0.6891839607 | 0.7895743384 |
| TreeFam-A | F1 | 0.6054035649 | 0.6025078294 |
| GO | Schlicker similarity | 0.47211905 | 0.49025964 |
| EC | Schlicker similarity | 0.93211406 | 0.96770222 |
| FAS | FAS similarity | 0.7749447305 | 0.7850068178 |

TreeFam-A F1 decreases; this is not a uniform endpoint improvement. The
R-on project-defined secondary mean is 0.7555392374929232, not official QfO
F1. Its 5,113,820 inferred pairs represent 542,365 of 984,137 inputs
(55.1107% all-input relation coverage, not accuracy). R-off uses group-clique
pairs; R therefore changes prediction semantics, not just group splitting.
P-off retains the initial HMM search and is not a non-HMM control. These
ablations are not the selected-default OrthoHMM-versus-OrthoFinder comparison.

Independent audits verify all 18 complete SwissTrees family records and
10,765 reference-pair labels. Both native cells exactly match retained
corrected records and aggregates. Only after these checks, one native
R-at-P0-C0 contrast reuses the original 100,000 shared bootstrap draws; all 42
endpoints remain in the multiplicity correction. The F1 difference is
+10.0390 percentage points, with nominal interval [1.1741, 18.9079] and adjusted
interval [-4.6418, 24.4199]. Precision rises 30.5212 points, adjusted
interval [14.3252, 46.5473], while recall falls 6.5334 points, adjusted
interval [-18.0413, -0.0436]. The adjusted F1 interval includes zero. This is
a conditional precision-recall trade-off among 18 development-exposed families,
subject to family exchangeability and approximate percentile coverage; it
does not establish general superiority or independent confirmation.

The recovered FAS sample contains 252,451 pairs and 257,077 proteins;
126,521 proteins appear in multiple sampled pairs (maximum degree 17).
Sampling is unseeded, and the 9,000 cap limits newly computed missing pairs,
not total precomputed-plus-new observations. Native pair-IID SEM is not a
paired confidence interval. Other QfO endpoint and secondary-mean paired
uncertainty remain open, along with the missing original TreeFam family labels.

[![Native QfO P0/C0 reconciliation ablation](native_qfo_p0c0_figure_20261006_v1/native_qfo_p0c0.png)](native_qfo_p0c0_figure_20261006_v1/native_qfo_p0c0.pdf "Vector PDF")

Figure: fresh native P0/C0 ablation on the QfO development set. A separates
three orthology F1 endpoints from B's GO/EC/FAS similarities. C shows the
SwissTrees precision-recall trade-off. D shows the R-on-minus-R-off effect
in percentage points; thick intervals are nominal 95% paired-family
intervals and thin intervals retain all 42 endpoints in adjustment. Intervals
are reused only after exact complete native family-record matches. There are
no error bars for other endpoints and no new bootstrap draws. Failed R-on
timing is excluded. Full-precision plotted values and provenance accompany
the figure; PNG and PDF assets were visually inspected separately from the
programmatic content readback.
[Two-cell score snapshot](native_qfo_scientific_scores_20261006_v1/scores.md),
[recovered result](RECOVERED_NATIVE_QFO_SCORE_RESULT_22449.md),
[guarded interval binding](native_qfo_swiss_uncertainty_binding_22449_20261006.json),
[figure review](NATIVE_QFO_FIGURE_RESULT_20261006.md).

This update does not replace the earlier comparator table, establish a
complete native factorial, or update the prior rc4 archive/PDF payloads.
Any reported timings are shared-Threadripper observations under competing
CPU, memory-bandwidth and I/O demand, with unknown, tool-dependent effects;
matching limits does not establish isolated performance. Failed timing stays
failed; broader publication requirements and final package integration remain.

### Third Native QfO Cell And Candidate-Expansion Trade-Off

Native P0C1R0 has independent scientific admission after native inference
22444, conversion 23892 and assessment 23894. The current combined snapshot
has three admitted cells and four unavailable score rows, including the
retained pre-inference failure at identity 9. No missing score is replaced
with a cached cell or zero. Both cells below retain the initial HMM search;
P-off disables downstream profile expansion, not HMMs altogether. With
reconciliation off, both submit cross-species group-derived clique pairs.

| Endpoint | Statistic | P0C0R0 | P0C1R0 | Difference (pp) |
| --- | --- | ---: | ---: | ---: |
| VGNC | F1 | 0.6668335336 | 0.6474454784 | -1.938806 |
| SwissTrees | F1 | 0.6891839607 | 0.6857094983 | -0.347446 |
| TreeFam-A | F1 | 0.6054035649 | 0.6336639072 | +2.826034 |
| GO | Schlicker similarity | 0.47211905 | 0.47053999 | -0.157906 |
| EC | Schlicker similarity | 0.93211406 | 0.92062409 | -1.148997 |
| FAS | FAS similarity | 0.7749447305 | 0.7503031364 | -2.464159 |

Candidate expansion produces 11,734,021 submitted pairs covering 585,610
of 984,137 input accessions (59.5049% all-input relation coverage), with
zero mapping loss. Coverage increases by 3.979121 percentage points; this
is not reference recall or accuracy. The project-defined secondary mean
is 0.6847143500310757, not official QfO F1. The mixed endpoint changes do
not justify a uniform improvement claim or tuning the frozen defaults.

The actual new SwissTrees raw output reproduces all 18 complete retained
family records and their aggregate. Independent CSV/gzip parsing and
rational arithmetic check 32,295 raw rows across the native baseline,
native candidate and retained candidate evidence; all 10,765 candidate
pair labels match the retained scored universe. This is not proof of
whole-partition or other-endpoint equivalence. Only after the exact family
match does the guarded binder reuse the original 100,000 draws (seed
20260922), retaining adjustment over all 42 planned endpoints. No new
bootstrap or scientific admission is generated by this readback.

| SwissTrees Metric | Difference (pp) | Nominal 95% Paired CI | 42-Endpoint Adjusted CI | Family Wins/Ties/Losses |
| --- | ---: | --- | --- | --- |
| F1 | -0.347446 | [-3.332692, 1.955055] | [-5.816832, 3.309051] | 5/8/5 |
| Precision | -3.523453 | [-7.426534, -0.291442] | [-10.229612, 0.373979] | 4/8/6 |
| Recall | +4.375165 | [2.100638, 6.872093] | [0.940111, 8.688718] | 9/9/0 |

Intervals recompute F1 of macro family precision and recall, not the mean
of family F1; the family win counts describe individual family statistics.
The adjusted F1 interval includes zero. The positive recall interval is
conditional on these 18 development-exposed families, the fixed contrast,
exchangeability and approximate percentile coverage. It establishes neither
general superiority nor independent biological confirmation. No paired
interval is supplied for the other QfO endpoints or the secondary mean.
FAS retains unseeded sampling and dependent-pair limitations; its native
pair-IID SEM is not a paired-family confidence interval.

[![Three admitted native QfO ablation cells](native_qfo_three_cell_figure_20261006_v1/native_qfo_three_cell.png)](native_qfo_three_cell_figure_20261006_v1/native_qfo_three_cell.pdf "Vector PDF")

Figure: three admitted native QfO cells. A shows orthology F1; B separately
shows GO/EC/FAS similarities; C shows all-input relation coverage, not accuracy.
D and E show candidate-expansion and reconciliation effects relative to
P0C0R0, respectively. Thick intervals are nominal 95% paired-family intervals;
thin intervals preserve the 42-endpoint adjustment after exact native family
matches. Both adjusted F1 intervals include zero. F shows native SwissTrees
precision-recall points. Four score rows remain unavailable; missing values
are not plotted as zero. No other-endpoint uncertainty, timing comparison or
independent validation is implied. Original Python3.10 binding replay matches
exactly; the exported score/coverage/interval tables, SVG labels, decoded PDF
text and all three cell colors pass independent content readback. PNG and PDF
preview were visually inspected separately from those programmatic checks.
[Figure outputs and reproduction](NATIVE_QFO_THREE_CELL_FIGURE_RESULT_20261006.md),
[presentation readback](native_qfo_three_cell_figure_readback_20261006_v1.json).

[Current three-cell scores](native_qfo_scientific_scores_20261006_v2/scores.md),
[admitted candidate result](FULL_NATIVE_QFO_CANDIDATE_RESULT_20261006.md),
[actual family counts](native_qfo_candidate_swiss_counts_20261006_v1.json),
[guarded interval binding](native_qfo_candidate_swiss_uncertainty_20261006_v1.json),
[independent raw/rational readback](native_qfo_candidate_swiss_readback_20261006_v1.json),
[reproduction and limits](NATIVE_QFO_CANDIDATE_UNCERTAINTY_RESULT_20261006.md).
Existing two-cell figures, seven-page supplement and rc4/PDF archive remain
historical snapshots, not updated final packages. Timing measurements were
collected on a shared Threadripper while other analyses were running.
Competition for CPU, memory bandwidth and I/O may have affected elapsed
times, with an unknown and potentially tool-dependent impact. These are
observed shared-host timings, not estimates of isolated performance.

### Native Candidate VGNC Error Decomposition

A prespecified raw decomposition adds the newly admitted P0C1R0 VGNC rows
to the previously independently verified P0C0R0 baseline pair table. Aggregate
outcomes were already inspected; this is not outcome-blind independent
validation. Candidate TP/FP/FN counts are 20,143/18,146/3,791, compared with
baseline 19,981/16,013/3,953. Both retain initial HMM search and submit group
clique pairs with reconciliation off.

| Baseline State | Candidate State | Scored Pairs |
| --- | --- | ---: |
| FN | FN | 3,791 |
| FN | TP | 162 |
| FP | FP | 16,013 |
| TP | TP | 19,981 |
| not_scored | FP | 2,133 |

The complete 42,080-pair union contains no other nonzero transitions.
Expansion recovers 162 asserted TPs but adds 2,133 scored FPs, retaining
baseline TPs/FPs. Precision decreases 2.904231 percentage points, recall
increases 0.676861 points and F1 decreases 1.938806 points. All added FPs
cross unchanged reference overlap blocks; the two within-block FPs remain.
This explains pooled-score arithmetic, not a causal evolutionary mechanism.
VGNC eligibility defines the scored denominator; `not_scored` is not a true
negative or proven biological non-orthology. Blocks do not establish valid
independent resampling units, and no VGNC confidence interval is admitted.

The separate stdlib reader checks all candidate raw rows, every sparse cell
and transition pair, original alias/reference mappings, aggregate metrics
and Fraction-based differences. Full candidate database hashes are checked
before and after reading. The original baseline raw audit is reused, not
repeated; omitted FPs are not independently rescored. No inference, scoring,
new admission, failed-timing repair or default tuning is performed.
[Protocol](NATIVE_QFO_CANDIDATE_VGNC_PROTOCOL_20261006.md),
[machine-readable decomposition](native_qfo_candidate_vgnc_20261006_v1/report.json),
[independent readback](native_qfo_candidate_vgnc_readback_20261006_v1.json),
[reproduction and limits](NATIVE_QFO_CANDIDATE_VGNC_RESULT_20261006.md).

The initial prespecified grouping-path export fails at accession
localization and is retained without retry. A separate stdlib graph traversal
independently reconstructs the complete 353,638 candidate groups from
394,328 baseline groups and 40,690 accepted unions, with all 984,137 genes
retained. All 42,080 transition rows are unique and canonically ordered, but
eight of the 2,295 changed pairs contain native-unmapped accessions
`Q17QN5_BOVIN` or `Q1RMT5_BOVIN`; all eight are added scored FPs. No identifier
substitution or approximate join is made. The initial diagnosis does not admit
complete pair-path localization, including the 2,287 changed pairs without missing
accessions. Matching whole partitions diagnoses software compatibility, not
biological truth or identical upstream hits; the reason for the identifier
difference is unresolved in that artifact. [Failed export, independent diagnosis and scope](NATIVE_QFO_CANDIDATE_GROUP_TRACE_RESULT_20261006.md).

A separately prespecified follow-up proves that the two scored identifiers
share original QfO protein numbers 594577 and 594851 with native accessions
Q17QN5 and Q1RMT5, respectively. Both original accession map and admitted
database agree on the protein/species identities, with exactly one native
accession per selected protein number. This is an explicit evidence-backed
join, not suffix stripping or an independent biological validation of the
mapping. The original failure remains immutable, and original scored IDs,
categories, metrics and admissions are unchanged. The separate stdlib reader
checks the proofs, complete partition and all 2,295 changed-pair ledger fields.

| First Connected Round | Path | Recovered TP Pairs | Added FP Pairs |
| ---: | --- | ---: | ---: |
| 0 | Direct cross-endpoint | 131 | 1,794 |
| 0 | Transitive union | 11 | 98 |
| 1 | Direct cross-endpoint | 19 | 239 |
| 1 | Transitive union | 1 | 2 |
| Total | All paths | 162 | 2,133 |

Thus 2,033 added scored FPs have direct cross-endpoint group paths and 100
have transitive paths, ruling out an all-transitive explanation. Group-level
direct connections do not necessarily imply direct sequence/HMM hits for
each protein pair; transitive connections do not imply absent search evidence.
Candidate eligibility, rejected alternatives and numeric support are not
recomputed. No causal support mechanism, biological homology/duplication,
confidence interval, default gain or superiority claim follows.
[Original-protein proof, complete paths and limits](NATIVE_QFO_CANDIDATE_ALIAS_GROUP_RESULT_20261006.md).

### Native Functional-Pair Composition

A separate raw-pair comparison explains the two fresh native cells' GO/EC
arithmetic without replacing their endpoints. All 78,607 R-on GO and 116,929
R-on EC scored pairs occur in the respective R-off sets (145,142 and 186,098
pairs), with identical six-decimal similarity values on every shared pair.
The 66,535 GO and 69,169 EC R-off-only scored pairs have means 0.4506870677
and 0.8719528955. These are lower than the shared means, explaining the
positive serialized differences (+0.0181405879 GO and +0.0355881593 EC)
through pair membership and original denominators rather than score changes
on common pairs. This is arithmetic composition, not correct ortholog
selection, annotation validation or causal biological improvement.

The realized FAS samples share only 1,007 pairs: 0.3989% of the 252,451 R-on
sample and 2.6358% of the 38,205 R-off sample. Their shared serialized values
are identical, but conditioning on this intersection changes the endpoint
and does not replace the original +0.0100620873 sample-mean difference.
Method-specific eligibility, unseeded sampling, missing scores and shared
proteins remain unresolved sampling/dependence issues. The scored GO/EC
pair sets likewise reuse proteins (maximum degrees 38-63 across the four
tables). Neither intersections nor these degrees define independent units;
no paired functional-score interval is added.

An independent SQLite parser/join checks all 817,432 rows across the six
admitted raw tables, including exact GO/EC integer totals, overlap counts,
shared-score equality and FAS means. The diagnostic does not rescore
annotations or establish an HMM-versus-OrthoFinder advantage. Its own
3.41-second shared-host execution is postprocessing, not native inference
timing or a scaling repeat; unknown contention effects remain.
[Native functional-pair result and limits](NATIVE_QFO_FUNCTIONAL_PAIR_RESULT_20261006.md),
[machine-readable composition](native_qfo_functional_pair_composition_20261006_v1.json),
[independent readback](native_qfo_functional_pair_sql_readback_20261006.json).

The original-release QfO factorial likewise completed all eight cells. Its
prespecified SwissTrees family bootstrap used 100,000 shared draws and
adjusted 42 endpoints. All 14 adjusted F1 intervals included zero. The four
reconciliation contrasts increased precision by 30.02-34.02 percentage
points and reduced recall by 4.56-6.81 points, with adjusted intervals
excluding zero in both directions. Their observed F1 gains of 10.40-13.12
points did not exclude zero after adjustment. All six adjusted C-by-R
interaction intervals included zero. This comparison changes native pair
inference versus group-derived prediction semantics, not only group
splitting. Only 18 development-exposed families were resampled; inference
for other QfO endpoints remains unfinished. The completed corrected-release
factorial is reported separately below.
[Full results and limitations](QFO_FACTORIAL_SWISS_RESULTS_20260918.md),
[generated 42-endpoint table](qfo_factorial_swiss_bootstrap_20260918.md),
[six-endpoint cell scores and prediction counts](qfo_factorial_endpoint_table_20260918/scores.md).

[![Original-release QfO SwissTrees factorial](qfo_factorial_swiss_figure_20260918/qfo_factorial_swiss.png)](qfo_factorial_swiss_figure_20260918/qfo_factorial_swiss.png "Full-resolution figure")

Figure: original-release SwissTrees cell scores and all 42 prespecified
conditional-effect and interaction endpoints. Thick intervals are nominal
95% paired family intervals; thin intervals retain Bonferroni adjustment.
Effects are shown in percentage points, including C-by-R differences of
differences. This is not the corrected-input rerun or a comparison against
OrthoFinder. The [figure manifest](qfo_factorial_swiss_figure_20260918/manifest.json)
binds the generated PNG/PDF/SVG files to their exact source result and plotter.

[![OrthoBench factorial scores and paired conditional effects](figures_orthobench_factorial_20260916/orthobench_factorial.png)](figures_orthobench_factorial_20260916/orthobench_factorial.png "Full-resolution figure")

Figure: all eight cell scores and 36 conditional-effect endpoints. Thick
intervals are nominal 95% paired RefOG bootstrap intervals; thin intervals
retain Bonferroni adjustment across all 36 endpoints. Each effect holds the
other two factors fixed. Profile-off retains initial HMM search; this figure
does not compare an HMM-free method or establish independent superiority.

An exploratory unconstrained replay used the same expanded candidate families
and reconciliation rules but omitted membership constraints. Native output
validation and official-score crosschecks passed. Its F1 was72.614510%,
precision76.092405%, and recall69.440641%, compared with74.106074%,81.770454%,
and67.755336% under constraints. Unconstrained-minus-constrained F1 was
-1.492 percentage points (three-endpoint Bonferroni interval[-5.873,0.931]);
precision decreased5.678 points ([-14.307,-0.794]) and recall increased1.685
points ([0.013,3.804]). Family F1 improved in5, tied in55, and declined in10
RefOGs. These development-exposed results describe a precision-recall tradeoff,
not a demonstrated F1 improvement or statistically established F1 loss.
They do not justify removing constraints as a new default.
[Diagnostic results](ORTHOBENCH_UNCONSTRAINED_RESULTS_20260916.md).

### Sequence-Search Replacement Control

With profile expansion, candidate expansion and reconciliation disabled,
the frozen HMM-search baseline scored69.763388% F1,78.868592% precision and
62.542944% recall. DIAMOND all-hit replacement scored65.762183/55.036231/
81.680884%; the post-search top100 diagnostic scored66.484803/55.897861/
82.019046%. Six-endpoint adjusted F1 intervals for control-minus-HMM were
[-14.834,6.688] and[-14.424,7.844] percentage points. Both include zero;
these results do not establish an HMM-specific F1 advantage. Precision was
lower and recall higher for both controls, with adjusted intervals excluding
zero. Each control improved family F1 in39, tied in10, and declined in21
RefOGs; the aggregate is not a mean of those family scores.

Hit sets were not sensitivity-matched. HMM/all-hit/top100 nonself counts were
18,235,373/99,848,167/48,740,683. Queries lacking cross-species hits numbered
33,351/24,526/24,526. DIAMOND all-hit recovery overlapped65.12% of HMM hits,
while only11.89% of its nonself hits were shared with HMM. This asymmetry is
not ground-truth sensitivity. The historical HMM cache omits self hits,
whereas DIAMOND retains250,980; raw no-hit query counts are not commensurate.
All three final partitions cover251,378 input genes, including singletons.
The same normalization formula and E-value cutoff do not equate calibration,
candidate filtering or computational effort. [Full control results](OB_SEQUENCE_SEARCH_RESULTS_20260916.md).

[Sequence-search control figure](figures_ob_sequence_search_20260916/sequence_search_control.pdf)
shows all observed scores and all six paired effects on a common percentage-point
axis. Thin intervals retain the six-endpoint correction; thick intervals are
nominal95% intervals. Search sensitivity/calibration are not matched, and this
control disables subsequent profile expansion and phylogenetic inference.

### Matched-Recall Simulation Search Control

A separately frozen diagnostic used all 70 retained variable-length simulation
datasets, splitting seeds 20261101-20261105 for calibration and
20261106-20261110 for reporting across seven conditions. Search sensitivity
was directed cross-species ancestral-family homology recall, including
paralogs: eligible families received equal weight within each dataset, then
datasets received equal weight. A single DIAMOND cutoff was selected from a
fixed 15-point grid solely to minimize calibration recall difference from the
fixed initial HMM search. No orthology score or reporting outcome entered
selection. The selected reported E-value cutoff was <=1e-40; the HMM search
retained its native <1e-4 rule. Reporting recall was 77.0904% for DIAMOND and
76.8033% for HMM. The prespecified gate passed: the overall absolute gap was
below two percentage points and each condition gap below five points.
[Protocol and complete grid](SEARCH_SENSITIVITY_RESULT_20260926.md).

After that gate, a second protocol froze downstream inference on the 35
reporting datasets. Both arms used the installed frozen production graph
and refinement APIs, Leiden CPM resolution 0.1, seed 4 and retained isolates.
HMM scores were already length-normalized; DIAMOND raw scores were divided
by the geometric mean of sequence lengths exactly once. Profile expansion,
candidate expansion and phylogeny were disabled. All 70 arms completed;
independent readback verified raw-to-numeric mappings, saved arrays, complete
partitions and separately reconstructed reciprocal-hit/singleton edges.
For the prespecified contrast, only final partitions were converted to
cross-species pairs and scored against
speciation-derived orthology truth, not ancestral-family membership.
[Downstream protocol](MATCHED_SEARCH_GRAPH_PROTOCOL_20260926.md),
[native validation](matched_graph_readback_20260926.json).

Mean pair F1 was 83.6097% for HMM and 80.5180% for DIAMOND, a +3.0917-point
difference with an eight-contrast adjusted interval of [+1.6782, +4.5313].
The 20,000-replicate PCG64 bootstrap (seed 20260927) resampled five paired
seed blocks, carrying all seven conditions together. The eight F1 contrasts
were the overall equal-condition mean and seven condition means. Five blocks
give limited tail resolution and approximate coverage; gene pairs and
shared-history conditions were not treated as independent replicates.
The largest differences were under divergence (+9.6223 points) and divergence
with turnover (+10.6832 points); uneven sampling slightly favored DIAMOND
(-0.1014 points, adjusted interval spanning zero). The remaining four adjusted
condition intervals touched zero. Mean precision was 90.7136% versus 91.0967%
and recall 83.4079% versus 79.9802% (HMM versus DIAMOND). All genes remained
represented; mean nonsingleton coverage was 94.7839% versus 93.4863%.
[All effects and intervals](matched_graph_scores_20260926/results.md),
[machine-readable records](matched_graph_scores_20260926/results.json).

![Matched-recall initial-search graph comparison, all seven conditions and overall; adjusted paired seed-block intervals.](matched_graph_figure_v2_20260926/matched_graph.png)

This supports a bounded advantage of HMM-derived initial-search evidence in
this graph procedure on these development-exposed simulations, especially
the divergent conditions. Matching recall does not equalize score distributions,
hit rankings, hit identities or computational effort. It neither identifies
a causal mechanism nor establishes real-data sensitivity equivalence,
independent confirmation, profile-expansion benefit or full-pipeline superiority
over OrthoFinder. The threshold is not transferred to QfO or OrthoBench;
shared-host resources remain descriptive. [Claim limits](MATCHED_GRAPH_RESULT_20260926.md).

A subsequent post-hoc diagnostic traced all 70 arms through accepted search
hits, saved graph edges and connected components, initial clustering,
singleton-augmented clustering and final refinement. Its protocol was recorded
after final outcomes were known but before stage-level outcomes were computed.
Every final-stage score reproduced the frozen result. The diagnostic uses
the same explicit orthology truth; overlap scores for direct hits, graph edges
and component closure are not treated as native ortholog prediction accuracy.
No additional intervals, significance tests or method tuning were performed.
[Protocol](MATCHED_GRAPH_STAGE_TRACE_PROTOCOL_20260926.md),
[complete stage trace](matched_graph_stage_trace_v2_20260926/results.md).

| Partition stage | HMM mean F1 (%) | DIAMOND mean F1 (%) |
|---|---:|---:|
| Initial clustering | 83.9344 | 80.6939 |
| Singleton-augmented clustering | 83.9571 | 80.7386 |
| Final refinement | 83.6097 | 80.5180 |

Most of the observed between-arm difference was present at initial clustering.
Final refinement reduced mean F1 in both arms: across the 35 dataset instances
it added 26 true and 1,221 false pairs for HMM, and 8 true and 895 false pairs
for DIAMOND, removing none. The final HMM partitions contained a mean 170.54
correct pairs per dataset without a direct accepted hit in either direction,
versus 50.20 for DIAMOND; false pairs without direct hits were also more common
(48.74 versus 26.31). Indirect graph paths can support these assignments.
These observations localize changes but do not isolate the causal effects of
hit identity, rankings, weights or clustering. Pair counts are descriptive,
not independent replicates. [Interpretation and negative results](MATCHED_GRAPH_STAGE_TRACE_RESULT_20260926.md).

Checksummed stage-level GNU-time records provide descriptive resource context.
Across reporting datasets, median elapsed search observations were 5.18 seconds
for HMM and 1.88 seconds for DIAMOND; median graph observations were 0.24 and
0.23 seconds. Median reported maximum process RSS was 119,944/21,504 KiB for
search and 41,472/39,936 KiB for graph inference (HMM/DIAMOND). DIAMOND database
preparation was separate (median elapsed time rounded to 0.00 seconds, not
zero cost). Search used four allocated CPUs; library threads in graph inference
were restricted to one. These shared-host observations are not a speedup or
memory-efficiency comparison: DIAMOND searched broadly at E=1 before filtering,
and reported process RSS is not simultaneous process-tree or cgroup memory.
Numeric export and scoring were not separately timed, so no complete
end-to-end total is available. Controlled matched-resource scaling remains
unmet. [Stage resources, CPU times and accounting limitations](MATCHED_STAGE_RESOURCES_20260926.md).

### Supplied-Tree Perturbations Had Small Observed Aggregate Effects

Six prespecified rooted topology perturbations were evaluated against an
unchanged supplied-tree control, with candidate groups, membership constraints,
raw gene trees and reconciliation rules held fixed. The control exactly
reproduced the inferred baseline partition and74.106074% F1. Three variants
had rooted clade distance2 and three distance4. Their F1 ranged from73.744102%
to74.270946%, or -0.361972 to+0.164872 percentage points relative to control.
Every one of the18 Bonferroni-adjusted F1/precision/recall intervals included
zero. Family F1 tied in62-69 of70 RefOGs per perturbation, although complete
predicted partitions changed. All runs preserved251,378 genes and passed
native-provenance checks and official-score crosschecks.

These observations describe this limited, development-exposed topology panel;
they do not establish equivalence, robustness to arbitrary species-tree error,
or improved tree estimation. Intervals remain compatible with larger effects
than the observed differences, and the variants are not posterior draws.
No variant was selected to change the method. Recorded reconciliation costs
reuse raw gene trees and are not end-to-end efficiency measurements.
[Full scores, uncertainty and coverage](OB_SPECIES_TREE_ROBUSTNESS_RESULTS_20260916.md).

[![Supplied-tree perturbation scores and all paired effects](figures_species_tree_robustness_20260916/species_tree_robustness.png)](figures_species_tree_robustness_20260916/species_tree_robustness.png "Full-resolution figure")

Figure: control and six fixed topology perturbations, ordered by the frozen
variant indices. Thick intervals are nominal 95% paired RefOG intervals;
thin intervals retain Bonferroni adjustment over all 18 endpoints using 20,000
paired resamples. Gene-tree checkpoints are shared; rooting/reconciliation
is recomputed against each supplied species tree.

### Exploratory Feature Strata Show Precision-Recall Tradeoffs

Fourteen feature strata were frozen before joining the new features to method
errors. They describe reference-family size, copy number, canonical alignment
identity, relative sequence length and global composition, not independently
verified duplication history, fragments or domain architecture. All 70 RefOGs
remain represented in each dimension. Twelve families have missing identity
because at least one aligned pair lacks comparable canonical positions.

Both OrthoHMM configurations were compared with full OrthoFinder 3.1.5 for
F1, precision and recall, retaining 84 endpoints in multiplicity adjustment.
Eleven bins had at least five families, yielding 66 interval-bearing endpoints;
one single-family composition bin was descriptive only and two empty bins
were explicitly nonestimable. None of the 22 adjusted F1 intervals excluded
zero. Nine adjusted precision/recall intervals excluded zero: two precision
advantages and seven recall deficits for OrthoHMM across overlapping strata.
These are not independent replications or tests of differences between strata.

In the 40-family short-relative stratum, high-sensitivity recall was 18.901
percentage points below OrthoFinder (adjusted interval [-36.475, -5.208]);
phylogenetic-mode recall was 14.833 points lower ([-34.240, -0.370]). In the
six large families, observed F1 differences were -16.469 and -11.616 points,
but both adjusted F1 intervals included zero. These observations do not prove
a fragmentation mechanism or justify outcome-selected parameter changes.

All three native-format parsers preserved 251,378 input genes, and fresh
full-reference sufficient statistics and official-score crosschecks reproduced
the frozen overall estimates. Stratified estimates restrict those original
per-family counts without changing the reference or low-certainty conventions.
Percentile intervals are approximate; the 84-endpoint adjusted tails contain
only about six of 20,000 resamples each. [All effects and limitations](OB_STRATIFIED_ERROR_RESULTS_20260916.md).

[![All stratified OrthoBench F1, precision and recall effects](figures_ob_stratified_errors_20260916/stratified_errors.png)](figures_ob_stratified_errors_20260916/stratified_errors.png "Full-resolution figure")

Figure: both OrthoHMM configurations minus full OrthoFinder3.1.5 across all14
prespecified strata, with identical horizontal scales. Filled points show66
interval-bearing endpoints: thick lines are nominal95% paired intervals and
thin lines retain the84-endpoint Bonferroni adjustment. Six open points are
descriptive estimates from a single-family stratum;12 endpoints in empty strata
remain explicitly nonestimable. Family counts are shown for every row. Strata
overlap, and differences between their effect estimates are not interaction
tests. Scores and points are checked against full-reference sufficient statistics;
the figure does not add new inference runs or independent biological evidence.

The descriptive extension retains these same fourteen bins for all eight
methods, using the full-reference family counts and unchanged scoring
conventions. Its 112 method/bin rows reproduce all 42 original rows; two
empty bins remain missing for every method. Independent rational arithmetic
verified the weighted counts and scores. The added five comparators do not
inherit the original three-method confidence intervals or 84-endpoint
adjustment. These development-exposed results do not establish independent
confirmation or justify tuning on subgroup outcomes.

![All eight methods across frozen OrthoBench strata: weighted F1, precision and recall.](ob_complete_strata_figure_20260928/ob_complete_strata.png)

Supplementary figure: all fourteen bins and eight methods in a fixed order,
with a common 0-100 percent scale. The display retains 288 finite scores and
48 NA cells across three metrics. Family counts are shown; bins overlap
across dimensions. Gray NA cells represent empty bins, not zero accuracy.
The concentrated-composition bin contains one family. No new intervals,
significance tests or causal mechanism claims are added.
[Complete score table and verification](OB_COMPLETE_STRATA_RESULT_20260928.md);
[figure provenance and reproduction](OB_COMPLETE_STRATA_FIGURE_20260928.md).

### Retained Checkpoints Localize Membership Changes

All70 OrthoBench families were traced across six retained checkpoints, with
40,733 pair rows checked against native partitions. Both assignments of the
one shared reference gene were preserved. The8,440 logged candidate merges
reconstructed the candidate partition;168 events touched reference genes.
These checks establish consistency of the retained evidence, not biological
correctness. Profile expansion starts from unrefined multipass clusters;
profile-off refinement is a separate branch, not its input.

Comparing matched refined endpoints, the profile-on branch gained836 and
lost160 within-family pairs. Candidate expansion added4,272; final tree,
reconciliation and constraint processing removed1,575. These raw co-membership
counts include within-species pairs and low-certainty assignments and are not
official benchmark recall. All six hash-selected illustrations were retained,
including neutral examples and candidate gains subsequently partly removed.
[Trace interpretation and full-family evidence](OB_FAMILY_TRACE_INTERPRETATION_20260916.md).
Rejected-search candidates, added profile-edge identities and per-family
tree/constraint mechanisms still require inspection; no biological mechanism
or new default is inferred from these membership changes alone.

Reconstruction of the250 reference-incident candidate families distinguished
root-lineage extraction from subsequent satellite membership constraints.
For114 reconciled and136 bypassed candidates, saved node calls and all193
local constraints exactly reproduced native final groups. Of1,575 lost
within-reference pairs,134 were separated by root-lineage rules and1,441
by subsequent constraints, affecting four and six families respectively
(one family in both sets). Among the frozen illustrations, losses inRefOG014
andRefOG021 occurred at the constraint step. These are execution-order
descriptions, not official recall, independent tree validation or a claim that
constraints should be removed; the unconstrained control showed a precision
cost without established F1 improvement.
[Full reconciliation trace and limitations](OB_RECONCILIATION_TRACE_20260916.md).

### Limited Parameter Sensitivity

The prespecified OrthoBench neighborhood changed CPM resolution, candidate
minimum normalized score, or candidate minimum margin by20% one at a time,
retaining all other settings and the full inferred-tree pipeline. CPM variants
recomputed their own HMM-refined seeds and candidates; threshold variants reused
the verified baseline seeds. Exact-input raw-tree reuse was allowed, but supplied
species trees were not substituted. All seven configurations retained251,378
input genes, passed native admission, and matched the official OrthoBench scorer.

Control F1 was74.106074%. F1 values were74.586147% and71.463468% for CPM0.08
and0.12,74.008570% and74.110826% for minimum normalized scores0.024 and0.036,
and74.973144% and73.274559% for minimum margins1.2 and1.8. Each of the six
F1 contrasts had a Bonferroni-adjusted interval including zero, using20,000
paired RefOG draws and all18 planned F1/precision/recall endpoints. The only
adjusted interval excluding zero was the recall decrease at CPM0.12:
-2.010 percentage points, adjusted interval[-6.291,-0.148]. Minimum normalized
score changes affected only one or three families' F1 values and left aggregate
recall unchanged; this is a local observation, not general invariance.

The largest observed F1 increase,0.867 points at minimum margin1.2, had an
adjusted interval[-1.362,4.316]. It does not justify default promotion or
an OrthoFinder superiority claim. This post-development panel is not independent
confirmation, and intervals including zero do not establish equivalence.
Shared-node phylogeny timings are incremental and omit upstream replay/candidate
costs.
[Complete scores and paired intervals](OB_PARAMETER_NEIGHBORHOOD_RESULTS_20260916.md).
[Parameter sensitivity figure](figures_ob_parameter_neighborhood_20260916/parameter_neighborhood.pdf).

The corrected QfO threshold panel subsequently completed native inference,
conversion, scoring and independent score validation for all four normalized
score and margin variants. On the 18 SwissTrees families, control F1 was
83.3513%. Both normalized-score variants had identical family statistics to
the control; their zero empirical contrast intervals describe this observed
reference panel, not equivalence on unobserved families or identical
whole-proteome predictions. Minimum margins 1.2 and 1.8 yielded F1 values of
82.8391% and 83.5648%, respectively. Their differences from control were
-0.5122 percentage points (adjusted interval [-4.1173, 1.3523]) and +0.2134
points ([-0.9285, 1.9571]); each contrast had one family win, sixteen ties
and one loss. Precision and recall adjusted intervals also included zero.

These intervals recomputed the native statistic in 100,000 paired family
draws using the frozen seed and all 18 planned endpoints for multiplicity,
including the CPM contrasts. The subsequent low-CPM result had SwissTrees F1
79.1014%, a difference of -4.2499 percentage points from control (adjusted
interval [-21.9395, 0.7887]). Three families improved, thirteen tied, and two
worsened; VATB had the largest family-level decline. A post-hoc retained-stage
trace located its separation before phylogeny: low-CPM refinement changed two
groups containing the 28 reference genes into 28 separate groups, including
27 singletons, and candidate expansion did not reunite them. The control
retained two groups. The affected low-CPM group contained 276 genes and up to
12 copies from one species, satisfying the frozen broad-panel copy-split rule
(at least 150 genes, 10 within-species copies, and 50 dataset species).
All 276 members were singletons after refinement. This supports the copy-number
guard as the explanation for this case, but is a post-hoc predicate/output
check rather than a dynamic branch trace or evidence for changing defaults.
Precision and recall intervals also included zero.
High-CPM replay failed with SIGSEGV. Its checkpoint continuation completed,
but independent validation and a subsequent allocator-debug refinement
diagnostic both failed during post-write partition readback. Written partitions
were byte-identical and covered the full gene universe, but this did not
establish safe execution or authorize an accuracy result. The native cause
remains unresolved. One subsequent prespecified refinement-only run under GDB
completed normally with the same partition and a valid completion report;
it did not reproduce the crash or provide a crash backtrace. This negative
reproduction under instrumentation does not repair the failed admission or
establish memory safety. A subsequent unchanged-runner refinement completed in
a separately reconstructed helper-complete runtime with default GC, reproducing
all retained output bytes. A distinct read-only admission explicitly names this
new independent-refinement runtime and verifies the original optimizer/checkpoint
evidence and complete graph/memberships; it admits the recovered seed only.
Historical failures remain failed. After preserving an import-order preflight
failure, source-corrected candidate construction completed using the unchanged
historical runtime/settings. Independent validation confirmed all 984,137 genes,
390,845 seed families, 346,866 candidate families and 43,979 reconstructed merges.
That gate admitted candidate content only. Subsequent distinct private-runtime
inference, native-pair conversion and six-challenge assessment passed independent
validation. A content-equivalent private control was validated before recovered
inference. The recovered high-CPM arm had SwissTrees F1 83.253016%, a difference
of -0.098306 percentage points from control (adjusted interval
[-1.050447, 0.747525]); one family improved, fifteen tied and two worsened.
Precision/recall differences were -0.056721/-0.120676 points, with adjusted
intervals [-0.264550, 0.007904] and [-1.501235, 1.107420]. Neither recovery nor
candidate/score admission diagnoses the historical crash or proves memory safety.
No missing result was imputed. The prespecified seven-arm SwissTrees parameter
panel is now complete: all 18 numerical endpoints were independently reproduced
within 1e-12 using unchanged controls, and all adjusted intervals include zero.
The other six point estimates and five contrasts exactly match the retained
partial analysis. These findings do not justify changing
frozen defaults and are development-exposed SwissTrees evidence, not a joint
uncertainty analysis of all QfO metrics or independent confirmation.
[Threshold results, provenance and reproduction](QFO_THRESHOLD_UNCERTAINTY_20260923.md).
[Updated low-CPM uncertainty and provenance](QFO_PARTIAL_PARAMETER_UNCERTAINTY_20260923.md).
[High-CPM validation failure evidence](QFO_ALLOCATOR_DIAGNOSTIC_RESULT_22158.md).
[One-shot GDB diagnostic](QFO_CPM_BACKTRACE_RESULT_22159.md).
[Explicit new-runtime recovered-seed admission](QFO_CPM_HELPER_RECOVERY_ADMISSION_RESULT_20260930.md).
[Independent recovered-candidate admission](QFO_CPM_HELPER_CANDIDATE_ADMISSION_RESULT_22386.md).
[Recovered high-CPM score admission](QFO_PRIVATE_CPM_SCORE_RESULT_22394.md).
[Complete seven-arm uncertainty, table and figure](QFO_COMPLETE_PARAMETER_UNCERTAINTY_20261001.md).
[Post-hoc VATB stage trace](QFO_VATB_PARTITION_TRACE_20260923.md).

## Limitations And Unfinished Analyses

The frozen significance filter remains approximate. The prespecified
synthetic null experiment demonstrates composition-dependent tails under
forced scoring, not real-data orthology error rates or calibrated profile
assignment confidence. Extrapolation to arbitrary composition, database size,
profile construction or band settings is unsupported; independent calibration
and validation would be required before making such a statistical claim.
Scientific defaults and all biological benchmark scores remain unchanged.

### SwissTrees Input Coverage

A [frozen numeric-identity audit](SWISS_SEQUENCE_ALIAS_AUDIT_20260917.md)
found 14 SwissTrees reference proteins without mapped accessions in the frozen
factorial FASTAs. All belong to the retained Xenopus tropicalis annotation
resource. Their 577 incident reference relations have identical native labels
across all eight retained tools: 181 false negatives and 396 true negatives,
with no true or false positives. [The relation audit](SWISS_MISSING_INPUT_RELATIONS_20260917.md)
preserves the full reference denominator and original scores. This common
component does not establish ranking invariance under removal, historical
input parity, or the cause of the input/reference resource mismatch. Those
provenance questions and any separately declared sensitivity analysis remain
outstanding; missing proteins are not relabeled as algorithmic fragment errors.

The subsequent [whole-input mapping audit](QFO_ORIGINAL_MAPPING_COVERAGE_20260917.md)
localizes a larger original-release mismatch to Xenopus: 990 input accessions
are unmapped and 8,623 reference numeric identities lack an original input
accession. All 78 canonical inputs match the original archive. EBI provides a
separate corrected 2020 release for this proteome. Subsequent
[archive comparison](QFO_CORRECTED_ARCHIVE_ACQUIRED_20260918.md) and
[native sequence/staging audits](QFO_CORRECTED_INPUTS_STAGED_20260918.md)
establish compatibility with the retained scorer: all 984,137 reference
identities are uniquely represented, including the 14 previously missing
SwissTrees proteins. Only the Xenopus canonical proteome differs from the
original archive. Of the corrected sequences, 983,959 match the native
reference exactly and 178 differ only by B/O/U/Z-to-X representation;
no unexplained difference remains. The 78 canonical FASTAs were staged
without residue normalization, with all identifiers, species ownership,
sequence counts and hashes checked independently.

This resolves the observed input/reference mismatch, not its effects on
method rankings. Original-input QfO scores and uncertainty estimates remain
explicitly release-limited. The separately frozen
[corrected-release protocol](QFO_CORRECTED_RELEASE_PROTOCOL_20260917.md)
requires fresh affected inference for all eight comparator rows and eight
factorial cells, with separate prediction identifiers and fresh scoring.
The corrected eight-method comparison is now admitted. Proteinortho yields
GO 0.486336, EC 0.963168, VGNC F1 0.954896, SwissTrees
F1 0.718111, TreeFam-A F1 0.643187 and FAS 0.813595, with 4,695,385 mapped native
pairs. Its project-defined secondary mean is 0.763216. SonicParanoid was
subsequently admitted with GO 0.454385, EC 0.872761, VGNC F1 0.982794,
SwissTrees F1 0.798459, TreeFam-A F1 0.771956 and FAS 0.736680, with
15,248,739 mapped native pairs and secondary mean 0.769506. A fresh frozen
admission reproduced its complete report byte-for-byte. These two rows
show different point-estimate trade-offs, not a uniform advantage. The
[earlier partial table](qfo_corrected_comparison_20260923_v6/scores.md)
is retained as historical evidence; the complete comparison and paired
SwissTrees uncertainty are reported below.
The admitted high-sensitivity OrthoHMM row now adds GO 0.472271, EC 0.932038,
VGNC F1 0.665933, SwissTrees F1 0.685498, TreeFam-A F1 0.605008 and FAS
0.776585 (secondary mean 0.689555), from 9,032,719 mapped group-derived
pairs. This is p1_c0_r0, not the p0_c0_r0 initial-HMM ablation. The checked
replay establishes its partition equivalence to the corrected native run.
The final phylogenetic OrthoHMM row (p1_c1_r1) is also admitted: GO 0.490349,
EC 0.965650, VGNC F1 0.901690, SwissTrees F1 0.833513, TreeFam-A F1 0.614864
and FAS 0.762993 (secondary mean 0.761510), from 5,959,560 mapped native
phylogenetic pairs with zero mapping losses. SwissTrees precision/recall
are 0.955177/0.739341, versus TreeFam-A 0.959110/0.452464. The table now
contains [eight admitted methods](qfo_corrected_comparison_20260926_v7/scores.md). Full OrthoFinder 3.1.5 adds
GO 0.469548, EC 0.936130, VGNC F1 0.988546, SwissTrees F1 0.848413,
TreeFam-A F1 0.791918 and FAS 0.691422 (secondary mean 0.787663), from
14,215,382 native phylogenetic pairs. Its pre-phylogenetic sequence-only
MCL checkpoint adds GO 0.407043, EC 0.753642, VGNC F1 0.142755,
SwissTrees F1 0.690515, TreeFam-A F1 0.734407 and FAS 0.561753
(secondary mean 0.548352), from 163,277,439 group-derived clique pairs.
Both conversions have zero mapping losses, but their output semantics
differ. The sequence-only checkpoint is a diagnostic, not native
pairwise orthology output. Full OrthoFinder has higher point estimates
on all three F1 endpoints than phylogenetic OrthoHMM, while OrthoHMM
has higher GO/EC similarity and FAS. Full OrthoFinder SwissTrees
precision/recall are 0.937853/0.774548, and TreeFam-A precision/recall
are 0.924527/0.692578. Relative to OrthoHMM, this is lower precision
and higher recall on both reference-tree tests, not a uniform advantage.
The [retained QfO provenance consolidation](QFO_ORTHOFINDER_PROVENANCE_CONSOLIDATED_20260926.md)
binds both OrthoFinder rows to the same 3.1.5 native execution on 78 proteomes
and 984,137 proteins. The diagnostic checkpoint has 167,209 groups; it was
not a separately timed sequence-only inference. Full-run GNU time records
42,018 wall seconds and 6,479,368 KiB maximum process RSS. Conversion took
193.52 seconds for native pairs and 249.17 seconds for checkpoint cliques.
These shared-host quantities have different measurement scopes, and maximum
process RSS is not aggregate concurrent-process memory. They do not support
a controlled speed or memory ranking.
FastOMA's corrected native pairs are now admitted: GO 0.436894, EC 0.897168,
VGNC F1 0.950096, SwissTrees F1 0.780219, TreeFam-A F1 0.657902 and FAS
0.654366 (secondary mean 0.729441), from 15,008,180 native pairs with zero
mapping losses. SwissTrees precision/recall are 0.923601/0.675373;
TreeFam-A precision/recall are 0.882105/0.524572. FastOMA used a supplied
corrected OrthoFinder species tree, not independent species-tree inference.
Two failed native task attempts were retained and explicitly audited against
their successful retries; their scientific commands were identical. This
is accuracy evidence, not controlled runtime evidence. OrthoMCL's corrected
scores are now independently admitted. Its interrupted search was recovered through
validated replay batches and an ordered merge. The full-table audit verified
401,908,030 alignment rows and 222,903,808 distinct directed pairs across
984,137 input proteins. It independently identified 53 failed queries:
46 statistics failures and seven short-query failures. None had outgoing
hits, but 21 had incoming hits. A subsequent audit against the independently
validated native partition found all 53 absent from the native graph index
and final groups, including the 21 with incoming hits. Thus incoming hits
did not result in final-group membership for these failed queries; this
does not establish the accuracy effect of repairing their outgoing searches.
[Failed-query membership audit](qfo_recovered_failure_membership_20260926.json).
The subsequent [direct reference-exposure audit](qfo_recovered_reference_impact_20260926.json)
found none of these 53 proteins in the 18 SwissTrees cases, pooled
TreeFam-A case, or 23,934 VGNC reference pairs. None has EC annotations;
four have experimental GO annotations under the benchmark filter.
All 53 have FAS annotation entries, of which 46 contain features.
Annotation presence does not establish participation in a scored pair.
These observations do not bound indirect clustering effects or estimate
the accuracy of a counterfactual run with repaired searches.
Another 4,257 proteins lacked query hits without a logged failure. Completed
BPO and native-group validation yielded 79,862 groups containing 781,432
proteins, with 202,705 ungrouped inputs. Pair conversion retained all
14,378,089 cross-species final-group clique pairs with zero QfO mapping loss.
These are cluster-derived pairs, not native phylogenetic ortholog calls.
The [independently admitted six-endpoint assessment](qfo_recovered_score_admission_22176.json)
yielded GO 0.463755, EC 0.921326, VGNC F1 0.642027, SwissTrees F1
0.766610, TreeFam-A F1 0.753685 and FAS 0.733752, with project-defined
secondary mean 0.713526. SwissTrees precision/recall are 0.874128/0.682644;
TreeFam-A precision/recall are 0.851985/0.675722. These results retain the
failed queries and native-representation differences described here; they
are not an uninterrupted or repaired-query BLAST counterfactual.

![Corrected QfO precision-recall and functional-similarity endpoints for all eight retained methods.](figures_corrected_qfo_endpoints_20260926/corrected_qfo_endpoints.png)

The corrected-input panel shows all 48 method/endpoint points. VGNC,
SwissTrees and TreeFam-A use precision-recall axes; GO and EC show mean
functional similarity against assessed relation counts. FAS uses reported
eligible relations, not the size of its unseeded sample. Different methods
submit different relation sets and output types, so functional similarity
does not establish overall orthology accuracy. FastOMA uses a supplied
OrthoFinder tree; the OrthoFinder sequence checkpoint yields group-derived
cliques. No cross-endpoint uncertainty is implied. Near-equal points may
overlap. [Vector PDF](figures_corrected_qfo_endpoints_20260926/corrected_qfo_endpoints.pdf)
and [point/provenance manifest](figures_corrected_qfo_endpoints_20260926/manifest.json).

The search was admitted under an explicit native-representation contract,
not exact residue parity: legacy BLAST deleted one O residue from each of
seven proteins while preserving all protein identities and the other
984,130 sequences exactly. A separate reference audit found no direct
membership of these seven proteins in the retained SwissTrees, TreeFam-A
or VGNC references. All seven have EC annotations and FAS features, and
none has an experimental GO annotation under the benchmark filter.
Annotation presence does not establish participation in scored pairs;
absence from a reference does not exclude indirect clustering effects.
A [final-group trace](qfo_native_residue_group_trace_20260926.json) places
all seven proteins in three single-species groups of sizes three, two,
and two, with no other members. They therefore contribute zero incident
cross-species pairs to the observed cluster-derived submission. This
does not establish what a residue-preserving search would have predicted.
[Residue-change reference exposure](QFO_NATIVE_RESIDUE_REFERENCE_EXPOSURE_20260925.md).
A complete scan of the recovered search table found 17 incident alignment
rows for these seven proteins: seven self pairs and ten non-self directed
pairs, all reciprocal. They form three isolated search components of sizes
two, three and two, all within one species; no observed hit in either
direction connects them to any other input protein. This describes the
retained legacy search, not a residue-preserving counterfactual: missing
cross-species hits could still be recovered under a different residue
representation. Neither the score impact nor the effect on final groups
has been established.
[Seven-protein search trace](QFO_NATIVE_RESIDUE_HIT_TRACE_20260925.md).
No paired superiority
over competitors is inferred from this point-estimate table alone.
[Method identity and export checks](QFO_CORRECTED_MAIN_TABLE_20260918.md).
The prespecified [corrected comparator uncertainty analysis](CORRECTED_SWISS_COMPARISON_RESULT_21987.md)
initially reconstructed raw counts for the six methods then admitted. It retained all
eight contrasts and the full 24-endpoint correction, using 100,000 shared
family resamples with seed 20260920. Phylogenetic OrthoHMM minus full
OrthoFinder F1 is -0.014900 (adjusted interval [-0.087078, 0.072090]); its
precision and recall intervals also include zero. Neither superiority nor
equivalence is established. Relative to high sensitivity, phylogenetic
OrthoHMM increases F1 by 0.148015 ([0.049791, 0.266015]) and precision by
0.314178 ([0.158952, 0.466178]); recall's adjusted interval includes zero.
This configuration contrast includes candidate expansion, not only phylogeny.
Full OrthoFinder has higher F1 than high-sensitivity OrthoHMM and Proteinortho
under the adjustment. The sequence-only checkpoint has lower precision and
higher recall than full OrthoFinder, while its adjusted F1 interval includes
zero. SonicParanoid's three adjusted intervals include zero. In that retained
six-method analysis, FastOMA and OrthoMCL contrasts were unestimable, not
zero. Independent arithmetic
reproduction matches all 18 available endpoints within 1e-12.

The [seven-method update](qfo_fastoma_swiss_uncertainty_22098.json) reuses the
same frozen executor, 18 families, 100,000 shared resamples and full
24-endpoint adjustment. FastOMA minus full OrthoFinder has F1 difference
-0.068194 (adjusted interval [-0.158907, 0.026407]), precision difference
-0.014252 ([-0.115839, 0.056552]) and recall difference -0.099175
([-0.239207, 0.054470]). All three adjusted intervals include zero; neither
superiority nor equivalence is established. Family-specific F1 differences
favor FastOMA in one family, tie in one, and favor OrthoFinder in 16.
These counts are descriptive, not a substitute for the macro-statistic
bootstrap. [Arithmetic reproduction](qfo_fastoma_swiss_reproduction_22098.json)
matches all 21 endpoints then available within 1e-12.

The [complete eight-method update](qfo_recovered_swiss_uncertainty_22178.json)
retains the same resamples and adjustment, with all seven existing contrasts
exactly unchanged. Recovered OrthoMCL minus full OrthoFinder has F1 difference
-0.081804 (adjusted interval [-0.159935, -0.008177]), precision difference
-0.063725 ([-0.183279, 0.032099]) and recall difference -0.091903
([-0.218861, 0.027759]). Thus its adjusted F1 interval is negative, while
the precision and recall intervals include zero. Family-specific F1 favors
OrthoMCL in three families, ties in one and favors OrthoFinder in 14.
[Independent arithmetic reproduction](qfo_recovered_swiss_reproduction_22178.json)
matches all 24 endpoints within 1e-12. These are conditional family-bootstrap
results on development-exposed references, not a universal ranking.

[![Corrected SwissTrees comparator differences with paired intervals](corrected_swiss_comparison_figure_20260926/corrected_swiss_comparison.png)](corrected_swiss_comparison_figure_20260926/corrected_swiss_comparison.png "Full-resolution figure")

This figure retains every planned contrast. Thick bars are nominal 95%
intervals and thin bars are adjusted across all 24 endpoints. Values are
percentage-point differences; the linked data retain raw units. These
conditional, development-exposed family intervals do not quantify uncertainty
on other QfO endpoints or the secondary mean, and cannot establish a
release effect by comparison with historical significance labels.

The prespecified [corrected composition-strata analysis](CORRECTED_SWISS_STRATA_RESULT_21981.md)
is now complete for the three primary configurations. Nine families fall
in each input-only entropy bin. With 100,000 paired resamples and adjustment
across 27 endpoints, phylogenetic OrthoHMM minus full OrthoFinder F1 is
-0.028710 (adjusted interval [-0.154364, 0.147961]) in the lower-entropy bin
and -0.006102 ([-0.089129, 0.068670]) in the higher-entropy bin. All adjusted
precision/recall contrasts for that comparison also include zero. Compared
with high sensitivity, the phylogenetic configuration improves precision
in both bins and F1 in the higher-entropy bin under the adjustment. All
adjusted higher-minus-lower interactions include zero. Thus these data do
not establish equivalence to OrthoFinder or a composition-specific causal
mechanism. The configuration contrast is not a pure phylogeny ablation.
All 27 endpoints appear in the linked figure, with an independent numerical
reproduction from the admitted counts. The [all-method descriptive tables](swiss_descriptive_strata_20260926/scores.md)
now include all eight admitted methods across
all frozen primary and secondary bins. In seven families containing a member
shorter than half the family median, F1 was 68.679% for high-sensitivity
OrthoHMM, 83.365% for phylogenetic OrthoHMM and 85.546% for full OrthoFinder;
the corresponding values in the other eleven families were 68.408%,
83.313% and 84.360%. These secondary summaries have no new inferential
claims and do not diagnose fragmentation. Empty concentrated-composition
and explicit-fragment bins remain missing, not zero. FastOMA's supplied
tree and sequence-only OrthoFinder's group-clique semantics remain explicit.
Recovered OrthoMCL scores 76.689% F1 in the relatively short bin and
76.353% in the other bin, and 68.933%/81.541% in lower/higher entropy bins.
Adding its admitted counts leaves every earlier method row unchanged.

An additional [exploratory identity-stratum analysis](CORRECTED_SWISS_IDENTITY_RESULT_22102.md)
froze the alignment and split protocol before joining the features to
outcomes. Corrected reference sequences from all 18 families were aligned
with MAFFT 7.525, with membership and ungapped residues checked against the
inputs. A separate scalar calculation reproduced all family mean canonical
pair identities. The median family identity, 0.429122, divides the panel
into nine lower-identity and nine higher-identity families. All eight admitted
methods have lower descriptive F1 in the lower-identity bin. Phylogenetic
OrthoHMM scores 73.973% versus full OrthoFinder's 76.705% in that bin, and
91.914% versus 92.600% in the higher-identity bin. High-sensitivity OrthoHMM
scores 64.023% and 72.435%, respectively. Recovered OrthoMCL scores 67.222%
and 83.426%, respectively, in the [complete table](swiss_identity_strata_20260926/scores.md).
Empty bins remain missing. No new subgroup intervals or significance claims
are made. Sequence identity is alignment-dependent, not calibrated
evolutionary divergence; correlated differences in taxa, domains, size and
composition prevent a causal interpretation.

A separate [historical fragment-annotation analysis](SWISS_HISTORICAL_FRAGMENT_RESULT_20260923.md)
matched all 563 reference proteins to sequence-identical UniSave entries;
549 matched the baseline-release interval and 14 required later records.
Eleven proteins carried fragment/incomplete-sequence annotations across
five families. Phylogenetic OrthoHMM and full OrthoFinder scored 83.827%
and 87.926% F1 in these families, versus 83.143% and 83.498% in the thirteen
all-matched unflagged families. Unflagged is not proven complete. Treating
later-version annotations as missing leaves eleven unflagged families and
changes that contrast to 84.562% versus 83.539%; the two excluded families
score 73.586% versus 83.062%. Both views are retained because the sign change
depends on family composition. These descriptive, development-exposed
associations do not establish a causal fragmentation effect or superiority;
no new subgroup inference is claimed. Recovered OrthoMCL scores 75.863%
in annotation-positive families and 76.952% in historical unflagged families;
the baseline-only unflagged and missing subsets score 76.283% and 80.258%.
[Complete fragment table](swiss_fragment_strata_20260926/scores.md).

A [prespecified duplication-annotation analysis](SWISS_DUPLICATION_FEATURE_PROTOCOL_20260923.md)
used the original trees embedded in the retained reference, with all 563
mapped memberships and 10,765 reference relationships reconstructed exactly.
Separate Python and Darwin traversals agreed on 128 explicitly annotated
duplication nodes among 546 informative mapped nodes. The other 418 nodes
used the reference's default-S convention, not explicit speciation evidence.
The median annotation fraction divided the panel into nine lower and nine
higher families. In the [complete descriptive table](swiss_duplication_strata_20260926/scores.md),
phylogenetic OrthoHMM scored 86.378% F1 versus full OrthoFinder's 90.453%
in the lower stratum, and 80.309% versus 78.991% in the higher stratum.
In the latter, precision/recall were 93.092%/70.613% for OrthoHMM and
91.320%/69.596% for OrthoFinder. High-sensitivity OrthoHMM scored 69.876%
and 67.218% F1 in the lower and higher strata. Recovered OrthoMCL scores
80.258% and 72.850%, respectively. All eight admitted methods
had lower absolute F1 in the higher stratum. The small positive OrthoHMM
contrast there does not reverse the full-panel ordering (83.351% versus
84.841%) or establish subgroup superiority. This annotation fraction is
reference-derived and related to the benchmark's own pair labels; alias
collisions, default-S nodes, family composition and development exposure
limit interpretation. No new subgroup intervals, causal claims or
duplication-rate interpretation are made. Empty bins remain NA.

::: {.review-figure style="break-inside: avoid; page-break-inside: avoid;"}

![Descriptive duplication-annotation differences in F1, precision and recall versus full OrthoFinder.](swiss_duplication_figure_20260926/swiss_duplication_descriptive.png)

**Supplementary Figure: Duplication Annotations.** Points show differences
for the nine lower and nine higher annotation-fraction families, with a
common horizontal scale across metrics. These are observed differences,
not confidence intervals or significance tests. The feature is derived from
the reference trees, not an evolutionary rate or an independent explanation
of benchmark errors. Full-panel scores and the empty missing bin remain in
the source table. All eight methods have admitted values in both plotted bins.
[Figure data and provenance](swiss_duplication_figure_20260926/manifest.json)
retain all 48 available endpoint records.

:::

::: {.review-figure style="break-inside: avoid; page-break-inside: avoid;"}

![Descriptive identity-stratified differences in F1, precision and recall versus full OrthoFinder.](swiss_descriptive_feature_figures_20260926/swiss_identity_descriptive.png)

**Supplementary Figure: Sequence Identity.** Points show observed differences
in percentage points for the nine lower-identity and nine higher-identity
families. No subgroup intervals or significance tests are added. Separate
x-axis ranges are used for each metric. All eight methods are included;
full OrthoFinder is the zero-difference reference. Configuration differences
are not isolated phylogeny effects, and identity is not calibrated distance.

:::

::: {.review-figure style="break-inside: avoid; page-break-inside: avoid;"}

![Descriptive historical fragment-annotation differences, including baseline-only sensitivity views.](swiss_descriptive_feature_figures_20260926/swiss_fragment_descriptive.png)

**Supplementary Figure: Fragment Annotations.** Observed differences versus
full OrthoFinder retain the positive (five families), historical unflagged
(thirteen), baseline-only unflagged (eleven) and baseline-only missing (two)
views. The positive family set is unchanged by baseline-only restriction.
Unflagged does not establish completeness; later-version records become
missing in the baseline-only view. No causal or inferential claim follows
from a subgroup sign change. [Figure data and provenance](swiss_descriptive_feature_figures_20260926/manifest.json)
link both figures to the pinned descriptive tables and all 144 displayed
endpoint records, all now available for the plotted bins.

:::

Old groups, trees, scores and confidence intervals cannot
be relabeled as corrected results. The corrected OrthoMCL search independently
yielded 53 failed queries, as described above; this does not transfer the
original run's group-membership or reference-impact conclusions to the new
run. Recovery of missing inputs
does not turn this development-exposed benchmark into independent validation.

A [sequence-content follow-up](QFO_SEQUENCE_DIFFERENCE_CLASSES_20260917.md)
found974,363exact byte matches among975,514mapped original inputs.
All178same-length differences are solely B/O/U/Z-to-X representation changes,
accounting for every non-Xenopus discrepancy. The remaining973length-different
pairs are all Xenopus. This separates observed residue representation from
the input-release issue without normalizing the frozen inputs or assuming
all inference methods treat nonstandard residues equivalently.

### Corrected QfO Replay Matches Native Grouping

The corrected-input high-sensitivity cached replay passed independent
admission after all four native clustering boundaries completed successfully.
Its final partition matched the corrected native result exactly: 391,908
groups covering 984,137 proteins, with no native-only or replay-only groups.
The admission workflow independently reread the partitions and checked 419
provenance records, including the frozen runtime and scheduler identity.
Retained intermediate outputs contained 308,697 multipass groups, 394,328
refined multipass groups, 306,051 strict-profile groups and 391,908 refined
strict-profile groups. Group counts alone are not accuracy endpoints.
[Independent admission and evidence](QFO_CORRECTED_REPLAY_ADMITTED_20260918.md).

This agreement supports reuse of the corrected intermediate outputs for
the prespecified ablations. It neither resolves the older historical-input
replay discrepancy nor establishes general determinism. Candidate
preparation was admitted before the factorial assessments; conversion and
scoring have since completed for all eight cells, as summarized below.
The 50:28 replay elapsed time is
incremental shared-host execution, not a matched end-to-end runtime result.

The corrected R-off cells p0_c0_r0, p0_c1_r0, p1_c0_r0 and p1_c1_r0 scored
SwissTrees F1 of 0.689184, 0.685709, 0.685498 and 0.686087, respectively.
Their group-derived predictions retained 9,009,082, 11,734,021, 9,032,719
and 11,755,521 cross-species pairs with zero mapping loss. These R-off cells
alone do not establish expansion/reconciliation interactions or authorize a
default change. [All six endpoints and admission provenance](QFO_CORRECTED_ROFF_SCORES_20260918.md).

Native inference and pair conversion have also completed for p0_c1_r1,
retaining all 984,137 genes and 5,977,100 native phylogenetic pairs with zero
mapping loss; its accuracy assessment is now independently admitted. An exploratory
comparison with p0_c0_r1 found that the inferred species trees differ:
both have the same 78 species and 76 nontrivial rooted clades, but share
only 38 clades (rooted symmetric difference 76). The runs used 18 versus
25 families for species-tree estimation. This contrast therefore includes
downstream tree estimation, not candidate expansion under a fixed realized
tree. Neither inferred tree is treated as truth, and the topology difference
does not establish a cause of an accuracy change.
[Native evidence and exploratory comparison](QFO_CORRECTED_EXPANDED_RECONCILIATION_20260919.md).

### First Corrected Reconciliation Contrast

Independent assessment admitted p0_c0_r1 with 5,113,820 native phylogenetic
pairs and zero mapping losses. Compared with the matched p0_c0_r0 ablation,
reconciliation increased precision and reduced recall in all three
reference-orthology endpoints. These comparisons retain initial HMM search
but disable multi-sequence profile expansion and candidate-family expansion;
neither row is the complete satellite_v2 publication configuration.

| Endpoint | Reconciliation off | Reconciliation on |
| --- | ---: | ---: |
| GO similarity | 0.472119 | 0.490260 |
| EC similarity | 0.932114 | 0.967702 |
| VGNC F1 | 0.666834 | 0.898185 |
| SwissTrees F1 | 0.689184 | 0.789574 |
| TreeFam-A F1 | 0.605404 | 0.602508 |
| FAS | 0.777125 | 0.785212 |

SwissTrees precision increased from 0.643940 to 0.949152 while recall fell
from 0.741266 to 0.675932. TreeFam-A precision increased from 0.792245 to
0.956682, but recall fell from 0.489873 to 0.439719, leaving slightly lower
F1. Thus a precision increase did not imply uniform F1 improvement. The
project-defined secondary mean increased from 0.690463 to 0.755573; it is
not a separate primary endpoint or evidence of general superiority.

All eight corrected factorial cells are now scored. Their
[machine-generated table and manifest](qfo_corrected_factorial_complete_20260919/scores/scores.md)
retain all corrected-release admissions. R-off pairs are group-derived cliques;
R-on pairs are native phylogenetic predictions, not root-HOG clique
expansions. Pair counts describe prediction volume, not protein coverage.
The prespecified full-factorial SwissTrees uncertainty analysis is complete,
as reported below. Historical-input intervals were not reused, and no
default was selected from these development-exposed point estimates.
[Independent score admission and precision-recall details](QFO_CORRECTED_FIRST_RECONCILIATION_SCORES_20260918.md).

### Corrected Profile Refinement With Reconciliation

With candidate expansion disabled and inferred reconciliation enabled,
multi-sequence profile refinement changes SwissTrees F1 from0.789574to
0.786372. The corresponding p1_c0_r1 scores are GO0.490229, EC0.968271,
VGNC F10.897844, TreeFam-A F10.602432 and FAS0.784576; the secondary
mean is0.754954. Five of six point estimates decline slightly and EC
increases. All5113180native pairs map without loss. These end-to-end
point estimates do not establish a significant effect or direct mechanism;
P-off still uses initial HMM search. All four corrected profile-refinement
F1 intervals include zero after adjustment.
[Validated scores and provenance](QFO_CORRECTED_PROFILE_RECONCILIATION_SCORES_20260919.md).

### Corrected Candidate Expansion With Reconciliation

With profile expansion disabled and reconciliation enabled, candidate
expansion increased observed SwissTrees F1 from0.789574to0.836354,
precision from0.949152to0.955781 and recall from0.675932to0.743456.
VGNC F1 increased from0.898185to0.901626 and TreeFam-A F1 from0.602508
to0.616864. Other endpoints decreased: GO similarity from0.490260to0.490035,
EC similarity from0.967702to0.965435 and FAS from0.785212to0.762823.
The secondary mean increased from0.755573to0.762189. These mixed point
estimates do not establish significance, a factorial interaction or superiority
of the complete publication configuration. The species tree also changes
between these cells, as described above; the contrast is end-to-end, not
fixed-tree isolation. The completed paired analysis below evaluates the
interaction separately; no historical interval is reused.
[Independently admitted scores and precision-recall trade-offs](QFO_CORRECTED_EXPANDED_RECONCILIATION_SCORES_20260919.md).

### Complete Corrected Factorial Uncertainty

The full p1_c1_r1 configuration has SwissTrees F1 0.833513, precision
0.955177 and recall 0.739341. Its six-metric secondary mean is 0.761510.
All 5,959,560 native pairs map without loss. Using 100,000 shared draws
over 18 families (seed 20260922), with the actual benchmark statistic
recomputed per draw and Bonferroni adjustment across 42 endpoints,
reconciliation at C1 increases F1 by 0.150644 [0.026173, 0.298879] at P0
and 0.147426 [0.024122, 0.295846] at P1. Candidate-expansion by
reconciliation F1 interactions are 0.050254 [0.003650, 0.124556] and
0.046552 [0.001825, 0.121851], respectively. The other ten F1 intervals
include zero. All four reconciliation precision intervals are positive,
while all four recall intervals are negative.

These conditional, development-exposed results support an end-to-end
interaction, not a fixed-tree mechanism or independent generalization.
Only 18 families are available, and adjustment does not account for prior
development selection. No corrected full-OrthoFinder superiority is
established. Fresh frozen admission, count-audit and bootstrap executions
reproduced the corresponding JSON outputs byte-for-byte.
[Complete scores, intervals, family effects and provenance](QFO_CORRECTED_FACTORIAL_COMPLETE_20260919.md).

[![Corrected-release SwissTrees factorial scores and conditional effects](qfo_corrected_factorial_figures_20260919/qfo_factorial_swiss.png)](qfo_corrected_factorial_figures_20260919/qfo_factorial_swiss.png "Full-resolution figure")

The corrected-release figure shows all eight cells and all 42 effects;
thick intervals are nominal 95% and thin intervals use the prespecified
42-endpoint Bonferroni adjustment. Effects are percentage points, whereas
the numerical differences above are raw 0-to-1 units. Profile-off retains
the initial HMM search. This figure is separate from the original-release
factorial figure and does not replace its historical evidence.
[Figure provenance and reproduction](CORRECTED_QFO_FACTORIAL_FIGURE_20260919.md).

### Corrected QfO Sequence-Search Control

Independent validation admitted the DIAMOND all-hit control with frozen
OrthoHMM downstream grouping:11,300,151cross-species clique pairs survived
reference mapping without loss. Endpoint scores were GO similarity0.479327,
EC similarity0.874662, VGNC F1=0.602031, SwissTrees F1=0.628092, TreeFam-A
F1=0.576306 and FAS0.715448. The project-defined secondary mean was0.645978.
The independently admitted top100diagnostic retained11,285,357mapped pairs
without loss and scored0.479791/0.874979/0.604172/0.629189/0.573917/0.716734
on the same six endpoints, with secondary mean0.646464. The same-input corrected
HMM control is now admitted (SwissTrees F1=0.689184). In the prespecified
100,000-replicate paired family bootstrap with six-endpoint adjustment,
all-hit minus HMM F1 was -0.061092 [-0.188023, 0.028017] and top100 minus
HMM F1 was -0.059995 [-0.186513, 0.029034]. Both precision differences
favored HMM (all-hit -0.082110 [-0.181914, -0.001387]; top100 -0.082123
[-0.181927, -0.001404]); both recall intervals included zero. Thus these
development-exposed controls support a bounded precision finding, not an
established F1 improvement. Equal cutoffs do not establish matched sensitivity
or effort. [Source-bound counts and uncertainty](QFO_SEQUENCE_UNCERTAINTY_RESULT_20260918.md).
[Both admitted controls](qfo_sequence_scores_20260918_v2/scores.md);
[top100provenance](QFO_SEQUENCE_TOP100_SCORE_20260918.md).

[Sequence-control uncertainty figure](figures_qfo_sequence_search_20260918/sequence_search_control.pdf).
The score table shows percentages. The three panels show all six DIAMOND
minus initial-HMM effects in percentage points, with a common symmetric
axis and zero reference. Thick lines are nominal paired 95% intervals;
thin lines are Bonferroni-adjusted intervals over the six endpoints.
Both F1 and recall intervals cross zero. Precision intervals exclude zero
but remain conditional on these 18 development-exposed families. The
[render manifest](figures_qfo_sequence_search_20260918/manifest.json)
binds the figure to the admitted result and renderer.

The completed [label-free search diagnostic](QFO_CORRECTED_SEARCH_COVERAGE_20260918.md)
compares initial search checkpoints on the same984137proteins and78species.
HMM search retained90,687,327directed hits, DIAMOND all-hits593,510,904 and
the top100control321,164,891. Queries with at least one cross-species hit
comprised74.44%,76.78%and76.78%of the input, respectively. Among non-self
directed hits,48,603,572were shared between HMM and DIAMOND all-hits,
representing54.1825%of HMM hits and8.2027%of DIAMOND hits. The HMM hit set
is therefore not a subset of DIAMOND's. These are output-set differences,
not calibrated sensitivity or independent orthology accuracy estimates.

[Search diagnostic figure](figures_qfo_hit_coverage_20260918/search_coverage.pdf).
Panel A shows directed-hit counts including self-hits; panel B shows the
fraction of all input queries with at least one cross-species hit, not
reference-relative recall. Both axes start at zero. The HMM checkpoint
precedes multi-sequence profile expansion and cannot measure full-pipeline
recovery. Top100 limits reporting per query and target species after search;
it is not a global100-hit limit or an HMM prefilter emulation. No confidence
intervals are attached to these complete-set descriptive counts. The figure
is generated from the [source-bound summary](qfo_hit_coverage_20260918/summary.json),
with [render provenance](figures_qfo_hit_coverage_20260918/manifest.json).

### Remaining Requirements

No universal superiority, arbitrary-dataset generalization, or controlled
speedup is established. Frozen YGOB evaluation is complete and supports
novel-taxon transfer, not family-disjoint confirmation. Homolog-family
overlap remains substantial even after taxon exclusions. The proposed HMM
contribution to F1 is not established by the completed exploratory OrthoBench
or corrected QfO sequence-search controls. Corrected SwissTrees precision
differences favor initial HMM under the prespecified adjustment, but F1 and
recall intervals include zero; independent confirmation remains required.
The subsequent matched-recall simulation graph control supports a bounded
initial-search F1 difference, not a reversal of those real-benchmark findings
or independent confirmation of full-method superiority.

The corrected-release QfO factorial supports a bounded SwissTrees finding:
reconciliation at expanded candidates improves F1 at both profile settings,
and both candidate-expansion-by-reconciliation F1 interaction intervals
exclude zero under the frozen 42-endpoint adjustment. The interactions are
+0.050254 [0.003650, 0.124556] with profile refinement off and
+0.046552 [0.001825, 0.121851] with it on, in raw 0-to-1 units. All four
profile-refinement F1 intervals include zero. Reconciliation increases
precision and reduces recall at each setting. This is conditional evidence
from 18 development-exposed families, not independent confirmation or a
mechanistic isolation of reconciliation: candidate expansion can alter tree
estimation, and reconciliation changes pair-output semantics. The earlier
original-release QfO interaction intervals included zero; both analyses are
retained, not conflated. No superiority over corrected full OrthoFinder is
established. [Complete corrected factorial](QFO_CORRECTED_FACTORIAL_COMPLETE_20260919.md).

Corrected-input evaluation now includes all eight retained comparator rows,
including OrthoMCL, with paired SwissTrees uncertainty. Matched search recall
and downstream graph controls are complete on the declared simulations;
real-data sensitivity matching and matched effort remain unestablished. Corrected multi-seed
simulations and their generating-tree/NNI controls are complete but do not
establish a full-pipeline OrthoHMM advantage or profile-expansion benefit. Tree perturbations
show bounded sensitivity, not arbitrary-error robustness. Completed annotation,
identity, fragment and duplication strata are descriptive; they do not establish
calibrated evolutionary divergence or causal error mechanisms. The biological
application trace localizes the focal losses but does not prove topology
correctness. More realistic evolutionary conditions, broader parameter/transfer
robustness, appropriate uncertainty for the other QfO endpoints and
controlled resource scaling remain required.

### TreeFam-A Pooled Count Audit

The separate [TreeFam-A count audit](QFO_TREEFAM_COUNT_AUDIT_20260917.md)
reproduced all four recovered-stage native endpoints from79,320raw reference
relations. This challenge stores one pooled case, not separately labeled
families. Of11,140mapped reference proteins,11,130occur in relations; ten are
isolated reference members and do not represent failed predictions. Native
confusion counts equal raw one-direction counts divided by two plus one prior
per pooled category. Appropriate family-level uncertainty remains unresolved
until original source-family mappings are recovered and validated. No
independent-pair bootstrap or degenerate single-case interval is substituted.

The [completed public QfO context search](TREEFAM_REMAINING_CONTEXT_RESULT_20260930.md)
now covers all 40 listed Darwin tag names at retained digests, representing
29 distinct recognized copied-context layers. The last 34 previously uninspected
tags all completed; independent descriptor/metadata/header readback finds no
original NHX/mapping filename candidate. Earlier layers were reused by hash
where shared, not downloaded again. This is bounded filename/header evidence,
not inspection of every other layer, platform, registry or archive-embedded
content, and does not establish global source unavailability. No container was
executed, member extracted, person contacted or family label inferred. The
original complete trees/mapping remain unrecovered.

Public archive recovery subsequently located historical Selectome exports
derived from TreeFam release 7: 1,211 TreeFam-A subtrees and a later 9,850-subtree
TreeFam-A+B collection. Both contain only Euteleostomi subtrees, not complete
source trees. The [taxonomic scope audit](TREEFAM_RECOVERED_SCOPE_20260928.md)
uses the existing QfO mapping for retained reference identifiers and the
Euteleostomi clade in retained phyloXML lineage metadata. Although that file is
in the 2020 resource directory, its title names QfO 2018; it is used as taxonomy
metadata, not a new 2020 species-tree inference. All observed reference species
have metadata. No Selectome gene identifiers are mapped in this analysis.

Of 11,130 incident reference proteins, 5,334 are outside Euteleostomi. At least
one outside-clade endpoint occurs in 55,933 of 79,320 relations (70.52%):
35,868 ortholog and 20,065 paralog relations. Relations with two outside
endpoints are counted once. Thus the recovered subtrees cannot reconstruct
the entire reference even if their identifier mapping were resolved. The
23,387 relations with both endpoints inside the clade are merely potentially
in scope; their gene, family and event coverage has not been established.
Ten reference proteins without relations remain outside this incident-protein
analysis. These counts bound taxonomic coverage, not prediction accuracy or
the effect of excluding taxa. Neither original-family labels nor confidence
intervals were inferred, and no benchmark reference or score was changed.

### Prespecified Whole-Genome-Duplicate Application

Experimental duplicate-pair evidence comes from
[Kuzmin et al. (2020)](https://doi.org/10.1126/science.aaz5667), with the
exact retained table recorded in the prospective application protocol.

The frozen application retained all 240 experimental duplicate pairs, of which
239 had both anchors in the prepared inputs and 231 shared an unambiguous YGOB
reference pillar. These Saccharomyces data are development-exposed, not an
independent generalization test. Full native runs and their output identities
were admitted before scoring. OrthoFinder was evaluated using its retained
root HOG table with bijective restoration of original sequence identifiers;
unassigned proteins were not supplemented with synthetic singleton groups.

High-sensitivity OrthoHMM separated 58/239 pairs, phylogenetic OrthoHMM 238/239,
full OrthoFinder 236/239 and SonicParanoid 229/239. Requiring each separated
anchor group to retain at least one non-S. cerevisiae reference homolog yielded
56/231, 193/231, 227/231 and 223/231 supported separations, respectively.
Mean reference-homolog coverage was 99.149%, 82.338%, 98.413% and 98.773%.
High coverage alone is insufficient: merged paralog groups can retain every
reference homolog. Conversely, splitting without homolog support can inflate
the unqualified separation rate.

Under the prespecified paired pillar bootstrap (20,000 replicates; seed
20260920; Bonferroni adjustment across 12 contrasts), phylogenetic OrthoHMM
improved supported separation over high sensitivity by 59.307 percentage
points (adjusted interval 49.784 to 68.398). However, it trailed full
OrthoFinder by 14.719 points (difference interval -21.645 to -8.225) and
lost 16.075 points of homolog coverage (-19.755 to -12.496). Against
SonicParanoid, the corresponding deficits were 12.987 points (-19.913 to
-6.494) and 16.436 points (-20.101 to -12.973). Thus, the results do not
support superior biological recovery by phylogenetic OrthoHMM.

These endpoints measure homolog-supported paralog separation, not correct
cross-species assignment to ancestral duplicate copies. All exclusions,
experimental strata, six prospectively selected examples and the diagnostic
OrthoFinder MCL checkpoint remain in the [machine-readable report](biological_wgd_results_20260917.json)
and [complete pair table](biological_wgd_pairs_20260917.tsv). The
[application figure](figures_wgd_application_20260917/wgd_application.pdf)
uses the same 231-pair population for all panels. Native-membership recalculation
with separate scoring arithmetic reproduced all 1,200 method/pair records,
class summaries and six selected examples. A direct pair-resampling calculation
reproduced all 12 intervals; this simplification is valid here because the
231 pairs occupy 231 distinct pillars. Native-format readers are shared, so
this does not constitute an independently implemented parser validation.

The [six prespecified cases](figures_wgd_application_20260917/PRESPECIFIED_EXAMPLES.md)
include success, partial recovery, a support failure and a reference exclusion.
YDR122W/YLR096W was merged by high sensitivity but separated with all six
non-S. cerevisiae homologs retained by phylogenetic OrthoHMM, full OrthoFinder
and SonicParanoid. For YER059W/YIL050W, all four methods separated the anchors
and retained all six homologs. In contrast, phylogenetic OrthoHMM retained
five of six homologs for each of YER132C/YGL197W and YBR147W/YOL092W, whereas
OrthoFinder and SonicParanoid retained all six. In both cases the reference
pillar intersected three OrthoHMM root HOGs rather than the two anchor groups.
For YCL048W/YDR522C, phylogenetic OrthoHMM separated the anchors but retained
only three of six homologs, all in one anchor group; the other anchor group
had no reference-homolog support. Full OrthoFinder and SonicParanoid retained
all six with support for both anchors. The sixth example, YLR284C/YOR180C,
remains reference-excluded because its anchors map to different pillars.
None was replaced after inspecting outcomes.

The [retained-artifact case trace](BIOLOGICAL_WGD_CASE_TRACE_20260917.md)
reconstructed seven incident candidate families, including two that bypassed
tree inference. It required exact agreement between reconstructed final groups
and admitted native membership. All five non-S. cerevisiae homologs outside
the anchor groups in the three partial-recovery examples were present in their
anchor candidates. They separated during root-lineage grouping, before the
satellite constraints were applied, and remained assigned to other final HOGs.
Candidate omission and subsequent constraint splitting therefore do not explain
these five observed coverage losses. Two incident families had unsupported
logged constraints, but those did not change these focal coverage outcomes.

This localizes the computational stage, not the underlying biological error.
The trace reproduces recorded node calls rather than independently validating
tree topology, rooting or duplication history. Node-table and family-checkpoint
hashes are retrospective, although tree/checkpoint consistency and exact final
membership were checked. Earlier search effects on candidate composition and
gene-tree inference remain possible. The two OrthoHMM configurations differ
in more than reconciliation, so their contrast is not an isolated phylogeny
effect. No assertion that every extra group is erroneous follows from this
homology-only reference.

QfO historical replay equivalence remains unresolved. A bounded capture
verified identical initial RBNH graph arrays and gene order but a different
first clustering partition than an earlier diagnostic. Thus the observed
discrepancy precedes profile refinement; its specific cause is not yet
established. No replay result is silently substituted for the historical
baseline. [Diagnostic evidence](QFO_REPLAY_DRIFT_DIAGNOSIS_20260916.md).
Three subsequent instrumented single-CPU workers with matching recorded
native-library/runtime identities reproduced the earlier diagnostic partition,
but not the replay capture. A subsequent controlled affinity panel exposed
within-configuration variability: the two one-CPU repeats differed (349,898
versus349,950 groups), although their recorded sources, libraries, inputs,
settings and affinity matched. Both32-CPU repeats produced349,898 groups.
Independent file and complete-partition admission confirmed the discrepancy.
Thus CPU availability alone does not explain the variation, and the earlier
matching repeats do not establish general repeatability. The cause remains
unresolved; no preferred partition is substituted for the historical baseline.

A subsequent native-boundary diagnostic stopped during its second worker
before optimization: ordered native endpoint hashes differed from the saved
graph despite matching vertex/edge counts and ordered weights. The first worker
had matched the saved graph before and after optimization. Fresh saved-array
hashing confirmed the expected endpoint fingerprint. This localizes a discrepancy
to pre-optimizer graph handling in that instrumented run, but does not yet
distinguish conversion, construction or observation effects, or establish the
cause of all historical partition differences. The failed partial panel is
preserved and not presented as a completed reproducibility experiment.

A second boundary diagnostic recorded six incorrect native edges despite an
intact original constructor array. A completed construction-only follow-up
alternated three original-int32 workers with three explicit-int64-copy workers.
Five graphs matched the saved endpoint stream; one explicit-int64 worker had
the same six endpoint mismatches. Both its original and converted arrays were
intact. Native tuple and source/target access agreed on the observed endpoints,
and edge lookup did not find the expected pairs. Independent admission checked
257 file records and reconstructed each worker's full reported native endpoint
hash from the saved arrays plus its complete bounded mismatch witnesses.
Explicit conversion alone is therefore not a sufficient fix in this experiment.
The audit validates preserved observations, not an independent inspection of
the historical live object; it does not establish a specific library defect,
hardware cause, or the cause of all historical variability. No optimizer was
invoked and no partition or accuracy score was produced in this follow-up.
[Construction evidence and limitations](QFO_CONSTRUCTION_DIAGNOSTIC_20260916.md).

A direct-construction follow-up completed six workers alternating minimal and
frozen-worker imports. Four had the same six endpoint mismatches before weight
assignment, two matched, and each worker's recorded differences were unchanged
after assigning weights. Both modes contained mismatching workers with intact
constructor arrays. Independent admission checked278 file records and reconstructed
all post-weight endpoint hashes. Pre-weight hashes are implied by bounded complete
witnesses, not separately recorded full hashes. Neither weight assignment nor
OrthoHMM/Leiden imports is necessary for this observed failure; its underlying
cause remains unresolved. This is preserved-observation evidence, not independent
live-object inspection or proof that every historical result is affected.
[Direct-stage results](QFO_DIRECT_GRAPH_RESULTS_20260916.md).

A six-worker input-format comparison subsequently completed: all three streamed
Python-integer-pair constructors matched the saved graph, while one of three
NumPy constructors had the same six pre-weight endpoint mismatches. Independent
admission checked278 file records and the full post-weight graph fingerprints.
This bounded result motivates integrity-gated follow-up, not a proven fix or
general repeatability claim; input format also changes allocation behavior.
No optimizer or accuracy score was produced in this comparison.
[Input-format results](QFO_CONSTRUCTOR_FORMAT_RESULTS_20260916.md).

Three subsequent integrity-gated initial-graph optimizer runs completed with
byte-identical partitions of349,898 groups covering all976,504 genes. Each used
Python-integer-pair construction and preserved all24,148,515 ordered undirected
edge endpoints and weights before and after unchanged CPM optimization.
Independent admission reconstructed saved hashes, checked308 provenance records,
and recomputed complete-coverage partition comparisons for every pair of runs.
This supports bounded repeatability of the checked initial-graph path, not general
determinism, a causal library diagnosis, or historical complete-pipeline equivalence.
No accuracy score was used to select an output; full cached-stage validation
remains required. [Checked-repeat results](QFO_CHECKED_REPEAT_RESULTS_20260917.md).

Historical timing and memory records differ in scope and accounting.
Cached replays are incremental computations, not end-to-end timings;
supplied trees have upstream costs. Unscheduled competing workloads were
observed, so exclusive Slurm allocation alone cannot establish controlled
CPU conditions. GNU-time maximum RSS and simultaneous process-tree RSS
must not be pooled as if they were the same measurement.

A subsequent dedicated ARM DGX panel completed 27 sequential runs at
20 CPUs and 96 GiB per allocation. Retained metadata and host-monitor
streams replayed successfully for all runs, as did the resource summaries
from 63,445 observations. However, all host assessments remained
inconclusive. The maximum observed persistent foreign load was 0.2112 CPU
cores, below the fixed 0.25-core monitor threshold, but this does not bound
unmatched or entirely unsampled work. Of 1,908 unmatched identity events,
1,710 were kworker-named; names were not treated as kernel authentication.

Process-read gaps were method-dependent: 838 affected samples for full
OrthoFinder, 3,868 for phylogenetic OrthoHMM, and none for high-sensitivity
OrthoHMM. These 4,706 samples contained 18,695 error events, mostly
NoSuchProcess (18,627). One OrthoFinder run had a process-read error at
its recorded aggregate-RSS maximum. Error-free sampled maxima in other
runs do not exclude missed between-sample peaks. Consequently, sampled
aggregate RSS does not support an unqualified cross-method memory ranking.
Cgroup memory and GNU-time maximum process RSS retain their distinct scopes.
All 27 native outputs subsequently passed input-universe, completion and
method-specific output checks. The complete archived inventory comprises
1,273,699 files and 18,018,339,602 bytes, including frozen inputs. Per-run
observations and three-repeat medians/ranges are retained as descriptive
results, not controlled-workload speed comparisons. No fastest-repeat
selection, speedup ratios, timing-based exclusions or automatic replacements
were applied. These limitations remain despite successful output validation.
[Native validation](dgx_native_output_validation_20260918.json),
[descriptive resource observations](dgx_descriptive_resources_20260918.json),
[all 27 runs](dgx_descriptive_resource_runs_20260918.csv).
The [descriptive resource figure](figures_dgx_descriptive_20260918/dgx_descriptive_resources.pdf)
shows all repeats, median ticks and observed ranges for elapsed time, CPU
use and cgroup peak memory. Ranges are not confidence intervals. Sampled
aggregate RSS is deliberately not plotted; no speedup or complexity fit is
implied. Host uncertainty is stated within the figure itself.
[DGX observation-gap audit](dgx_observation_gaps_20260918.json),
[post-run validation status](DGX_POSTRUN_ADMISSION_20260918.md).

A separate prospective 18-task observation-overhead experiment subsequently
finished. It compared periodic and boundary-only monitoring in three paired
replicates for each principal method on the four-proteome input. Independent
audit validated six task records; three measurement wrappers failed and
nine tasks lacked the required detailed scheduler records because accounting
summaries had been collected instead. Only one of nine planned pairs was
available. Its 1.986% periodic/boundary wall-time difference does not establish
the prespecified complete-panel overhead budget or an interference bound.
No missing pair was imputed and no failed arm selectively replaced.
[Complete audit and failures](DGX_FRONTIER_OVERHEAD_RESULT_21838.md).

In two failed wrappers, retained snapshots identify transient apt-daily and
NetworkManager-dispatcher cgroups as the reason for identity-check rejection;
their effect on native runtime is unquantified. The third failed inside a
snapshot and lacks the two inventories needed for that diagnosis. All three
native exit records report success, distinguishing measurement failure from
demonstrated inference failure. Subsequent engineering changes automate
scheduler-record capture and preserve partial failed-snapshot evidence, but
do not retroactively recover these missing records or admit the panel.

An independent [host-pressure audit](DGX_PRESSURE_DIAGNOSTIC_21838.md)
checked 5,154 retained points and their source hashes. Seventeen observation
windows enclosed native execution; task 6 covered only 10.038107 seconds
before monitoring failed. Recorded host memory-stall totals were small
(0-227 microseconds for the `some` category), while CPU and I/O pressure
varied. Host-wide pressure includes native work and does not identify
competing processes or establish isolation. No pressure threshold was
selected after observing these outcomes. The original 27 runs remain
descriptive; controlled speed and memory rankings are not established.

A subsequent pressure-enabled overhead panel retained all 18 detailed
terminal records and validated 16 tasks, yielding seven of nine complete
pairs. Three-pair median periodic/boundary changes were -0.710027% for
high-sensitivity OrthoHMM and +0.077954% for satellite_v2; only one
OrthoFinder pair was available. Negative differences represent variation,
not negative measurement cost. The complete-panel overhead budget remained
unestablished. [Pressure-overhead audit](DGX_PRESSURE_OVERHEAD_AUDIT_21889_20260919.md).

Three prospective native diagnostics then retained two host-counter brackets
around the same native CPU observations. All native products matched the
prescribed prior outputs. The narrower bracket flagged 0/551 intervals for
high sensitivity, 21/819 for satellite_v2 and 1/622 for full OrthoFinder;
original wider-bracket flags were preserved. These non-atomic residuals do
not identify foreign CPU activity. [Native diagnostic audit](DUAL_NATIVE_RESULT_21912_20260919.md).

A prespecified nine-trial control experiment compared steady work, repeated
short-lived process creation and steady work with a known outside-target
competitor, in three balanced blocks. Twenty native workers were pinned to
the allocated CPUs for 20 seconds; independent witnesses checked scope,
affinity, exits, CPU dose and at least 19.5 seconds of common work. All nine
trials passed those checks. The narrow screen flagged 0/126 native-only
intervals and 63/63 contended intervals, including all 57 fully enclosed
common-work intervals. Churn increased within-block median residuals by
0.07845-0.08762 cores; contention increased them by 0.94738-0.94930 cores.
Both increased native CPU pressure, so pressure alone was not specific
evidence of outside work. [Control audit](FULL_NODE_CONTROL_RESULT_21918_20260919.md),
[descriptive comparisons](FULL_NODE_CONTROL_DESCRIPTION_20260919.md).

Post-outcome recomputation on fixed 5-, 10- and 30-sample endpoint grids
reduced satellite_v2 narrow flags to one, zero and zero, respectively, and
OrthoFinder flags to zero at each scale. Known sustained competitors remained
detectable. Every final partial window and original interval flag was retained.
Aggregation can obscure brief real interference as well as accounting noise;
it therefore does not establish a cause or justify retrospective acceptance.
The controls support bounded monitor behavior, not controlled speed rankings.
[Window-scale diagnostic](CPU_WINDOW_SCALES_20260919.md).

The subsequent 18-task dual-collector overhead panel is complete: 16 tasks
passed native-output/provenance and measurement-replay checks, while two
periodic satellite_v2 measurements failed when transient service cgroups
appeared during sampling. Seven of nine assigned pairs are available.
Median signed periodic-versus-boundary wall-time differences were 0.6067%
for high-sensitivity OrthoHMM and 1.0411% for full OrthoFinder. Each met its
5% median numerical budget, but the satellite_v2 median and complete-panel
budget remain unestimable. All seven available pairs met the 60-second
duration and 10% per-pair numerical gates and had matching canonical
outputs. These within-method collector comparisons are not tool speed
rankings. Twenty-three narrow interval flags remain in the seven validated
periodic tasks; failed observations were not dropped or selectively retried.
No scientific timing inclusion rule has been adopted, and controlled
comparative timing remains unestablished.
[Completed audit](DUAL_OVERHEAD_RESULT_21920.md),
[machine-readable summary](dual_overhead_summary_21920_20260919.json),
[prospective protocol](DUAL_COLLECTOR_OVERHEAD_PROTOCOL_20260919.md).

An aggregate-lineage collector subsequently completed all three native
diagnostic workloads without the earlier sibling-inventory failure.
Provenance, raw-measurement replay and native-output validation passed;
canonical outputs matched the pinned same-method predecessors, with no
temporal-order or boot-domain discrepancies. Original interval flags numbered
1, 56 and 0 for high-sensitivity OrthoHMM, satellite_v2 and full OrthoFinder,
respectively; the corresponding narrow counts were 1, 7 and 0. These flags
remain retained. Non-atomic ancestor-counter differences do not identify
their cause or bound interference. Successful output reproduction therefore
does not establish environmental validity or admit comparative timings.
[Native lineage audit](LINEAGE_NATIVE_RESULT_21995.md).

A complete new 18-task periodic-versus-boundary lineage overhead experiment
was frozen with the same workloads, paired order and numerical budgets.
All 18 tasks completed and validated, with all nine paired work/duration
checks passing. Median signed periodic-versus-boundary wall changes were
+0.085529%, -0.505169% and +1.614059% for high sensitivity, satellite_v2 and
full OrthoFinder, respectively. All numerical overhead budgets passed.
Negative values reflect variability, not acceleration by monitoring.
The panel retained 143 original and 23 narrow interval flags; boundary-only
observations explicitly lack interval coverage. Remaining CPU discrepancies
and prospective scientific timing inclusion remain unresolved. No timing
correction or scientific speed ranking follows.
[Completed audit](LINEAGE_OVERHEAD_RESULT_21999.md).
[Protocol](LINEAGE_COLLECTOR_OVERHEAD_PROTOCOL_20260919.md),
[deployment and submission](LINEAGE_OVERHEAD_SUBMISSION_21999.md).

Exploratory inspection retained all 5,929 periodic intervals, including the
23 narrow flags. Flagged root-minus-system.slice CPU differences were
positive, but non-atomic counters did not identify their cause.
[Complete interval description](LINEAGE_OVERHEAD_FLAGS_21999.md).
In a separate prespecified engineering control, three finite owned services
each consumed approximately 0.75 process-CPU seconds and disappeared between
the lineage reader's root and next ancestor reads. All three controls and
their raw evidence replay passed. Full-span signed root-minus-observer
responses were 0.809154, 0.814570 and 0.811985 CPU seconds; the first partial
spans were negative and retained. This demonstrates bounded lifecycle
handling and read-window skew, not the cause of native flags, attribution
specificity, arbitrary-churn robustness or controlled comparative timing.
[Read-crossing control and replay](LINEAGE_READ_CROSSING_RESULT_22018.md).

A subsequent 12-trial root/user-slice context panel stopped at its first
user-contended condition when the user-manager session had already shut
down. The initial idle, steady and churn trials replayed successfully,
with zero original or narrow flags in their 63 total observation intervals;
the failed condition and eight unrun conditions are retained. This incomplete
panel does not establish sensitivity to the intended user-service load or
scientific timing eligibility. [Failure and raw replay](ROOT_CONTEXT_RESULT_22019.md).

The separately identified held-session follow-up validated all 12 controls.
All three user-contended trials exceeded the fixed five-CPU-second aggregate
response criterion, with 57/57 common-work intervals flagged versus 0/171
idle/native-only intervals. An unrelated restarting user daemon remained
present and is documented. This supports the tested monitor response under
the recorded environment, not background-free timing, exact task attribution
or context-collector overhead on native tools.
[Complete follow-up and replay](ROOT_CONTEXT_RESULT_22020.md).

The subsequent native integration panel completed all three frozen
four-proteome commands with replayable supplementary root context and
canonical outputs equal to the prior lineage diagnostics. Across 1,976
intervals, 52 original and 11 narrow flags remained; none were removed.
The bounded waiting session was verified, but an unrelated failing user
service scheduled 383 restarts during the job window. These results establish
native collector integration, not background-free measurements, causal
attribution, collector overhead or comparative timing eligibility.
[Native integration and retained flags](ROOT_CONTEXT_NATIVE_RESULT_22021.md).

A prospective paired panel subsequently validated all 18 native tasks and
nine lineage-versus-root-context comparisons against the same-method native
baseline. Median signed elapsed-time changes were -0.929631%, +1.342841% and
-0.344162% for high sensitivity, satellite_v2 and full OrthoFinder. All pairs
met the prespecified +10% limit and all complete method medians met +5%.
All 344 original and 60 narrow flags across 11,846 intervals were retained.
Fixed order and an unrelated restarting user service limit interpretation:
these are incremental collector comparisons, not causal overhead estimates,
method-speed rankings or scientific timing admission.
[Paired overhead results and provenance](ROOT_CONTEXT_OVERHEAD_RESULT_22022.md).

The retained non-CPU assessment found positive native-step I/O pressure in
all 18 overhead runs and positive memory pressure in the six satellite_v2
and six full-OrthoFinder runs; the six high-sensitivity runs recorded zero
memory pressure. All recorded memory-event counters, including OOM events,
were zero. These are observation-window counters, not exact command-only
stall times or evidence identifying outside interference. Neither zero native
pressure nor absence of sampled foreign processes establishes isolation;
requiring zero pressure could selectively exclude legitimate native work.
Device-I/O attribution, GPU activity over the full run, thermal effects and
memory-bandwidth interference remain uncharacterized.
[Non-CPU assessment and retained records](DGX_NON_CPU_ASSESSMENT_20260920.md).

A [prospective replacement protocol](DGX_SCALING_REPLACEMENT_PROTOCOL_20260920.md)
preserves all 27 original method/size/repeat identities, scientific settings,
nested input bytes and order, with fresh outputs and no automatic retries.
Each intended allocation is exclusive, with 20 CPUs, 96 GiB, a 24-hour limit
and a 23-hour-50-minute native timeout. The
[long-run amendment](DGX_SCALING_LONG_RUN_AMENDMENT_20260920.md) corrects the
short diagnostic collector's incompatible timeout contract before launch;
it does not alter scientific parameters or historical measurements. Native
failures retain consumed resources, while infrastructure or policy failures
pause further submissions. No fastest-repeat selection, pressure subtraction
or observed-overhead correction is planned. Complete three-repeat summaries
require three eligible, output-valid runs, with unavailable outcomes visible.

The replacement panel has not been executed. Short collector probes verified
temporary suppression and restoration of the explicitly authorized failing
user service, terminal scheduler handling, and relocated raw replay; these
are infrastructure diagnostics, not method timings or environmental admission.
The service's missing application remains unrepaired. On 23 September 2026,
the user deferred further DGX work. Task binding, raw replay and
outcome-classification tests do not establish whole-run environmental validity
or native-output correctness. The actual service/workload policy, complete
environmental observations and controlled replacement timings remain unmet.
The original 27-run panel remains descriptive evidence only; local queued
accuracy analyses are not replacements for controlled comparative timing.

### SwissTrees Comparator Uncertainty

For all eight retained historical comparison outputs, raw SwissTrees counts
covered the same 18 reference families and 10,765 labeled relations. Reconstructed
native per-family precision and recall, with confusion counts raw/2+1, reproduced
the retained macro statistics. A committed follow-up protocol specified 100,000
shared family-bootstrap draws (PCG64 seed 20260920), seven contrasts against full
OrthoFinder and one contrast between OrthoHMM configurations. Every replicate
recomputed macro precision/recall and their harmonic mean. Percentile intervals
were adjusted across all 24 contrast/metric endpoints.

All seven comparator-minus-full-OrthoFinder adjusted F1 intervals were negative.
For phylogenetic OrthoHMM, the difference was -0.067184 (adjusted interval
[-0.127608, -0.021232]); for high sensitivity it was -0.185310
[-0.285081, -0.091574]. Phylogenetic OrthoHMM had lower recall than full
OrthoFinder; its precision difference interval included zero. Against high
sensitivity, phylogenetic OrthoHMM had a positive F1 point difference of 0.118125,
but its adjusted interval [-0.007676, 0.241518] included zero. Its precision
increase of 0.304810 [0.150217, 0.455082] remained positive under this adjustment.
All differences are in raw 0-to-1 units.

These are approximate conditional sensitivity estimates for 18 curated,
development-exposed families, not independent or model-selection-adjusted
confirmation. Disjoint represented genes do not remove shared evolutionary
history or dependence from merged predictions. Inclusion of zero does not
establish equivalence. The OrthoFinder checkpoint remains a diagnostic, FastOMA
used a supplied tree, and the OrthoHMM configuration contrast is not a pure
reconciliation ablation. The results do not quantify uncertainty for other
QfO challenges or the six-metric secondary mean.
[Full results and family contrasts](QFO_SWISS_COMPARATOR_INTERVALS_20260917.md).
[The uncertainty figure](figures_qfo_swiss_comparators_20260917/swiss_comparator_intervals.pdf)
shows every prespecified contrast in percentage points, with nominal and
adjusted intervals; the [figure note](QFO_SWISS_COMPARATOR_FIGURE_20260917.md)
provides its caption, validation scope and reproduction command.

### Annotation-Defined SwissTrees Error Strata

An annotation-only inventory found exact accession matches for all 563 represented
SwissTrees proteins in the retained QfO FAS resource. Five records had no Pfam
hits, distinct from absent annotation. A committed follow-up protocol split the
18 families by median distinct Pfam types: 12 below two and six at least two.
The secondary repeated-type split contained 15 and three families and was
reported descriptively without inferential intervals. These annotations are
external to predictions but are not independent validation of the FAS endpoint.

The planned within-bin family bootstrap used 100,000 draws (PCG64 seed20260921),
recomputed macro precision/recall and harmonic F1, and adjusted 27 endpoints
covering three method contrasts, two primary bins and their interaction.
Both OrthoHMM configurations had negative adjusted F1 differences versus full
OrthoFinder in both primary strata. Phylogenetic-minus-sensitive OrthoHMM F1
was +0.185688 in the higher-type bin (adjusted interval [0.024605, 0.413865])
and +0.085765 in the lower-type bin [-0.074822, 0.222339]. All nine adjusted
interaction intervals included zero; the F1 interaction for that configuration
contrast was +0.099922 [-0.121894, 0.379765]. A within-bin interval excluding
zero in only one bin does not establish that the effects differ between bins.

This retrospective comparison is not a causal domain-effect analysis. Few
curated families, shared history, merged predictions and correlated differences
in taxon sampling, divergence or family size limit interpretation. Pfam types
and repeated hit instances are annotation features, not independent fragment,
domain-loss or ancestral duplication labels. No bin or threshold was changed
after observing stratified outcomes, and no method was retuned.
[All strata and contrasts](SWISS_DOMAIN_STRATA_RESULTS_20260917.md).
The [domain-stratified figure](figures/swiss_domain_strata_20260917/swiss_domain_strata.pdf)
shows all 27 endpoints, including the nine neutral adjusted interactions;
its [caption and reproduction note](SWISS_DOMAIN_STRATA_FIGURE_20260917.md)
documents the fixed source and validation.

### VGNC Prediction-Database Audit

For the four recovered sequence-refinement stages, a separate audit reconstructed
native true-positive, false-positive and false-negative pair sets from the mapped
prediction databases. Every category matched the retained raw output exactly,
and precision, recall and harmonic F1 matched the admitted endpoints within
5e-8. The native reference contains 23,934 asserted pairs and 36,986 proteins;
11 proteins have multiple family labels. Native final-label and accession-alias
behavior was retained and verified against raw annotations.

The multipass, multipass-refined, strict-profile and strict-profile-refined stages
respectively predicted 232,314, 40,460, 232,521 and 40,520 pairs among reference
proteins. Of these, 88,316, 4,739, 87,865 and 4,798 were neither asserted true
positives nor eligible native false positives. Thus the precision denominator
does not include every predicted pair even within this reference subset. This
is native benchmark scope, not a newly imposed exclusion. These checks validate
scoring of these databases, not upstream conversion completeness, independent
family resampling, or every publication competitor.
[Reference and prediction audit](QFO_REFERENCE_MAPPING_AUDIT_20260917.md).

A [dependency-structure audit](VGNC_DEPENDENCY_STRUCTURE_20260918.md) collapsed
overlaps among 16,863 family labels, yielding 16,844 reference blocks.
All scored true positives and false negatives lay within these blocks,
whereas 120,804, 15,788, 121,468 and 15,804 false positives crossed blocks in
the four stages, respectively; each stage had only two within-block false
positives. Thus merging overlapping reference labels alone does not justify
ordinary independent-family resampling of the native precision denominator.
Connected components of prediction links also vary with the method and are
not used as outcome-defined resampling units. These observations explain an
unresolved dependence problem; they provide neither confidence intervals nor
proof that valid paired inference is impossible. VGNC remains a point-estimate
endpoint with an explicit uncertainty limitation.

An exploratory [fixed-table influence diagnostic](VGNC_BLOCK_INFLUENCE_RESULT_20260918.md)
then deleted each reference block's incident scored rows separately. Across
all16,844 deletions, neither refinement's positive F1 difference nor the
strict-profile stages' small negative F1 differences changed sign. The
refinement differences ranged from+39.0496 to+39.2274 percentage points
without strict profiles and+39.1141 to+39.2909 with strict profiles.
These dependent deletion ranges are not confidence intervals. This checks
single-block influence on historical scored tables only; it neither reruns
native eligibility nor establishes generalization or comparator superiority.

### Additional VGNC Uncertainty Validation

The [corrected eight-method readback](CORRECTED_VGNC_BLOCK_MAPPING_20260926.md)
maps retained native rows onto the same 16,844 reference-defined blocks and
reproduces all admitted precision, recall and F1 values. Phylogenetic OrthoHMM
has 19,660 TP, 13 FP and 4,274 FN, compared with 23,519 TP, 130 FP and 415 FN
for full OrthoFinder. These counts make the precision-recall trade-off
explicit; they do not establish method superiority. Most reference blocks
(14,075) contain just one asserted pair. Supplemental raw-table hashes and
selected reference mappings were checked, but this is not a requery of every
prediction edge or full database-content verification.

The [corrected deletion sensitivity analysis](CORRECTED_VGNC_INFLUENCE_RESULT_20260928.md)
extends the historical diagnostic to all eight methods and all 16,844 blocks.
Its protocol and runner were committed before the corrected calculation.
All 134,752 deletions retain incident-cell counting: a within-block cell is
removed once, and a cross-block cell is removed when either endpoint is the
deleted block. Precision, recall and F1 are recomputed from remaining counts.
All seven method-minus-full-OrthoFinder F1 differences remain negative for
every matched deletion. Phylogenetic OrthoHMM's range is [-8.7353, -8.6729]
percentage points, compared with its full-table difference of -8.6856 points.
An independent rational-arithmetic check reproduces every deletion and all
seven paired ranges/sign counts. These are not confidence intervals: deletions
are dependent, alter the scored table and do not requery native eligibility.
No inference about joint deletions, population sampling or new datasets follows.

A [prespecified family-pair variance screen](DYADIC_F1_VARIANCE_RESULT_20260926.md)
completed 8,000 synthetic replicates. Candidate paired-F1 Wald coverage was
93.2-95.3% in six in-model cells, but 79.1-82.7% when groups of families shared
additional effects. A separate [reference-size and rare-error screen](SPARSE_DYADIC_F1_RESULT_20260926.md)
completed 6,000 replicates using only the reference size histogram as a
real-data input. Regular unequal-size cases had 93.3-94.9% coverage. With
perfect recall and fixed expected false-positive counts of two versus one,
coverage was 61.3-65.1%; zero variance estimates were retained as failures.
This stress case has a non-vanishing probability of observing identical
paired counts despite a nonzero population contrast. More families alone
do not restore a regular Wald approximation when expected errors stay fixed.

These simulations are statistical diagnostics, not evolutionary simulations
or models fitted to named tools. Their failures do not prove all native
contrasts invalid, but prevent blanket adoption of the candidate. Biological
exchangeability and dependence beyond shared family endpoints remain
unestablished. No new VGNC confidence intervals are admitted, and the
uncertainty limitation is retained rather than obscured by aggregate variance
agreement or selectively passing simulation cases.

## Data And Code Availability

The [standalone YGOB arithmetic replay](YGOB_ARITHMETIC_REPLAY_RESULT_20261002.md)
uses identifier-free retained counts to reproduce all 12 point metrics and
six nominal/adjusted interval endpoints after local archive restoration.
This is not native re-admission, proof of pillar exchangeability or independent
family validation; original transfer scores and overlap limitations remain.

A separate [frozen-source installation](PUBLICATION_FROZEN_OVERLAY_INSTALL_20260926.md)
uses scientific revision `7f3a9e4` with a versioned setup-only packaging overlay.
All 33 shipped scientific source files match their frozen Git blobs; the new
compiled wheel is not represented as the historical benchmark executable.
The [exact installed-artifact inventory](FROZEN_OVERLAY_ARTIFACT_INVENTORY_20260926.md)
binds 11 wheels to their installation hashes and notice metadata and verifies
all 42 entries of the project wheel's RECORD and its embedded license.
This is not complete transitive dependency or redistribution clearance.

Independent readers additionally checked the historical OrthoBench phylogenetic
baseline from inputs through output serialization. They validated all 8,681
gene-family alignments, 200 species-tree marker alignments and the reconstructed
181,089-column supermatrix; independently derived 337,845 reconciliation node
records; and reproduced 59,770 final root groups and all 966,439 native
pair/confidence records under the frozen membership policy. The hierarchy's
209,159 rows and all reconciliation/bypass selections also agree. The
hierarchy describes nodes before satellite-membership filtering, unlike the
final root groups and native pairs. These checks establish consistency with
the frozen rules conditional on saved rooted trees, not biological truth,
optimal rooting or correctness of upstream HMM search.
[Sequence validation](PHYLOGENY_SEQUENCE_READBACK_20260926.md),
[event and pair validation](PHYLOGENY_EVENT_READBACK_20260926.md), and
[hierarchy semantics](PHYLOGENY_HIERARCHY_READBACK_20260926.md).

External-tool build evidence includes a [MAFFT source rebuild](PUBLICATION_MAFFT_SOURCE_BUILD_20260926.md)
whose 34 core helper files match the retained installation and a separate
[baseline-x86-64 FastTree build](FASTTREE_BASELINE_BUILD_RESULT_20260926.md)
with identical binaries across two private builds. A help-banner validator
failure was preserved and corrected without recompilation. Using those
FastTree bytes with rebuilt MAFFT, the installed OrthoHMM pipeline passes the
unchanged 16-protein fixture and all independent phylogeny readbacks; five
primary outputs match the earlier fixture byte-for-byte. These small-fixture
results do not establish full-dataset equivalence, cross-platform operation
or controlled runtime performance. The fresh installed full OrthoBench run,
using rebuilt MAFFT and the identified historical FastTree executable, completed
and passed all five independent output readbacks. It was not numerically
equivalent: weighted RefOG F1 was 73.821569%, versus historical 74.106074%,
with eight of 70 reference-family records changed. Historical benchmark scores
were not replaced. [Full-run readback](INSTALLED_ORTHOBENCH_READBACK_20260926.md).

Post-hoc diagnostics found identical retained directed search-hit presence and
identical initial graph topology, with maximum score/weight differences of
8.881784197001252e-16. Those weight differences did not alter initial clustering
in the installed runtime. In contrast, holding the graph, indexing, seed and
scientific worker source fixed while changing from the installed runtime to
the current Anaconda replay-launcher environment changed initial groupings for
23,352 genes (58,827 versus 58,772 groups); each runtime's fixed repeat agreed.
The environments report leidenalg 0.12.0 and 0.11.0, respectively, but this
whole-runtime contrast alone neither isolates that dependency nor establishes
the historical environment's unchanged identity. A subsequent private overlay
of the complete retained leidenalg 0.11.0 distribution in the otherwise unchanged
clean runtime reproduced the exact 58,772-group alternate partition in two
calls. This isolates that distribution, including its bundled native libraries,
as sufficient for the initial-clustering change, but does not distinguish its
individual components or causally account for the full-run score difference.
A subsequent fixed-checkpoint replay carried both distributions through profile
refinement and candidate expansion. Both started from identical graph arrays,
but yielded 54,495 versus 54,445 candidate families, with changed memberships
for 30,788 genes. The 0.12.0 result exactly reproduced the fresh installed
candidate partition. The 0.11.0 result still differed from the historical
candidate partition for 93 genes, despite an identical total group count.
Thus the distribution effect propagates downstream but does not fully restore
historical candidates or establish the cause of the final F1 difference.
No phylogenetic replay or default change was made in this diagnostic.
[Downstream readback](OB_DEPENDENCY_REPLAY_RESULT_22320.md).
The [residual trace](OB_CANDIDATE_RESIDUAL_TRACE_20260926.md) finds all four
retained pre-candidate partitions byte-identical to historical outputs in the
0.11.0 arm. The remaining discrepancy first appears during candidate expansion:
8,427 of 8,440 merge events are shared, with 13 distinct events per side.
Shared-event support/margin differences are of order 1e-14. A subsequent
[fixed-seed score/order factorial](OB_CANDIDATE_ORDER_SCORE_RESULT_22322.md)
reproduced the entire 93-gene residual by changing hit order alone: historical
order matched historical candidates, while fresh order matched the 0.11.0
fresh replay, regardless of which observed score values were used. A self-hit
control had no effect. This establishes order sensitivity at candidate
formation in this case, but does not isolate individual numerical operations,
attribute the final F1 difference, or by itself validate a revised deterministic
policy. An experimental canonical directed-pair input policy was subsequently
tested across all five fixed-seed score/order/self-hit arms. Independent
integer-key reconstruction reproduced its input hashes, and all five candidate
files were byte-identical to the historical 54,445-family output. Historical
and fresh score vectors remained distinct. This bounded ordering control does
not establish final phylogenetic/F1 reproduction or cross-runtime determinism;
production defaults remain unchanged. A subsequent
[membership-boundary audit](CANONICAL_MEMBERSHIP_CONSTRAINTS_20260926.md)
found all 8,440 directed source/target constraints in the same semantic order
as the historical trace for every canonical arm. Raw trace bytes differ, but
the pinned membership consumer ignores those differing numeric metadata fields.
Its inputs are therefore equivalent conditional on identical family outcomes;
newly inferred trees and those outcomes were not validated by that boundary check.
In a subsequent [fresh phylogeny-stage reproduction](CANONICAL_OB_PHYLOGENY_RESULT_22324.md),
the canonical full-fresh candidate input and matched private clustering
distribution yielded exactly the historical 59,770-group root partition and
all 70 reference-family score records: F1 74.106074%, precision 81.770454%
and recall 67.755336%. All 8,681 reconciled families and the species tree were
inferred without historical checkpoint reuse, and four independent scientific
readers passed. This recovers the historical result in the tested OrthoBench
case; it is not cross-platform determinism, QfO confirmation, or a new
independent accuracy result. The differing fresh-installed run is retained,
and production defaults remain unchanged. Search was reused from the validated
fresh run, so the 1,555.40-second replay is a descriptive phylogeny-stage time,
not a fresh full-pipeline or controlled comparative timing measurement.
[Canonical candidate control](OB_CANONICAL_CANDIDATE_RESULT_22323.md).
[Private distribution control](OB_LEIDEN_OVERLAY_PROBE_20260926.md).
[Search](INSTALLED_OB_SEARCH_COMPARISON_20260926.md),
[graph](INSTALLED_OB_GRAPH_PROBE_20260926.md),
[weight control](INSTALLED_OB_CLUSTERING_PROBE_20260926.md), and
[runtime contrast](OB_CLUSTERING_RUNTIME_PROBE_20260926.md).

A separate [full-native candidate-only diagnostic](NATIVE_CANDIDATE_FACTORIAL_RESULT_22429.md)
evaluated P0C1R0: sensitive initial HMM search, profile expansion disabled,
satellite candidate expansion enabled and reconciliation disabled. The fresh
and cached outputs each contained 54,745 groups covering 251,378 genes,
but 58 genes occurred in changed groups. None touched the frozen reference;
the separately evaluated OrthoBench statistic was unchanged. This is distinct
from the 93-gene dependency-control discrepancy above.
Five prospectively fixed arms crossed historical/fresh hit order and score
values, with a fresh self-hit control, using the original seed bytes/order,
unchanged parameters and frozen refinement function. Both complete saved
partitions were reproduced. Changing order alone reproduced the whole
58-gene difference; score-value changes alone did not change either
respective partition, and self-hit inclusion had no partition effect.
Independent accepted-union and gene-level readbacks reconstructed all five
partitions and checked all ten pairwise comparisons. Under the order-only
intervention, common accepted counts, maximum scores and coverage agreed,
while support changed by at most 1.42e-14; three round-zero anchors selected
different attachments at the four-satellite cap. Stable within-pair order
before floating-point aggregation provides an order-sensitive path. This
identifies a fixed-boundary effect, not universal determinism, original
upstream order provenance, individual machine-level causality or a new
accuracy advantage. No default was changed, score rounded or phylogeny run
by this diagnostic. Its duration is not comparative timing; shared-host
distortion remains unknown and potentially tool-dependent.
[Complete five-arm table](native_candidate_factorial_22429/summary.md).

A subsequent [fresh recovery installation](PUBLICATION_RECOVERY_INSTALL_20260926.md)
uses a complete 11-wheel hash lock, including a provider-digest-verified Leiden
0.11 wheel whose 15 payload files match the validated private distribution.
An independent audit checks 3,052 installed package files against wheel bytes
and 33 scientific sources against the frozen Git revision. Explicit exclusions
cover installer-generated metadata/bytecode and relocated non-site payload;
this is not exhaustive filesystem or security attestation. Standard and
high-sensitivity fixtures each produce four groups covering 38 genes. A
[fresh inferred-phylogeny fixture](PUBLICATION_RECOVERY_PHYLOGENY_20260926.md)
also passes all four scientific readers in this environment, with 16 genes,
three root groups and 36 ortholog pairs, without tree checkpoint reuse.

An [explicit experimental entrypoint](PUBLICATION_FULL_PIPELINE_FIXTURE_20260926.md)
then executes the complete pipeline from raw FASTA in this installation. It
applies canonical directed-pair ordering only at the candidate expansion
boundary, leaving score values, upstream inference and installed scientific
sources unchanged. A 16-gene fixture reorders 96 candidate-input hits and
recovers three root groups and 36 pairs with all four scientific readbacks
passing. Its satellite merge trace is empty; this establishes the execution
path, not validation of full-data merge behavior. Initial output-directory
and empty-constraint audit failures are retained and documented. Package audits
remain identical after execution. Neither fixture transfers the earlier full
OrthoBench score to the newly installed environment.

A [prespecified full OrthoBench run](FULL_RECOVERY_ORTHOBENCH_PROTOCOL_20260926.md)
was therefore launched from the 12 proteomes, using this entrypoint and no
search or phylogeny checkpoint reuse. It pins inputs, installed payload,
scientific sources, external tools, settings and historical references. The
[dependent readback workflow](FULL_RECOVERY_READBACK_PROTOCOL_20260926.md)
requires successful terminal scheduler state and exact execution provenance,
then independently validates scientific outputs and recomputes the complete
historical/current score objects. Native job 22326 and independent audit 22327
subsequently completed successfully. The
[full-input recovery result](FULL_RECOVERY_ORTHOBENCH_RESULT_22326.md)
reproduced all 59,770 root groups across 251,378 genes, including exact root
partition file bytes, and all 70 reference-family score records. Recomputed
F1 was 74.106074%, precision 81.770454% and recall 67.755336%, with 15 exact
RefOGs. Four independent scientific readers passed; before/after installation
audits were identical. Unlike the earlier partial-stage replay, this run
regenerated search, alignments and inferred species/gene trees from raw FASTA.
GNU time recorded 9,438 wall seconds, 268,824.98 user seconds, 3,254.68 system
seconds and 6,163,636 KiB maximum process RSS. The latter is not simultaneous
process-tree peak memory, and shared-host timing is descriptive rather than
a controlled comparison. This establishes same-host full-pipeline recovery
for the explicit entrypoint and pinned environment, not independent accuracy
confirmation, QfO reproduction or cross-platform determinism. Canonical
ordering remains an explicit experimental policy, production defaults are
unchanged, and earlier discrepant runs remain retained.

A prespecified [paired QfO candidate replay](QFO_ORDER_REPLAY_RESULT_22328.md)
tested the same ordering policy on 90,687,327 admitted hits and identical
profile-refined seeds across 984,137 genes. Retained order exactly reproduced
the historical 351,739 candidate groups and 40,169 directed membership
constraints. Canonical order changed two groups containing 49 genes and five
constraint positions, despite preserving both total counts. A
[dependency trace](QFO_ORDER_DEPENDENCY_TRACE_20260927.md) localized the
difference to two proteins exchanging singleton/family assignments; all
351,737 shared families retained their IDs and both arms selected the same
ordered 26 species-tree marker families.

The completed [fresh retained-order phylogeny replay](QFO_FRESH_PHYLOGENY_RESULT_22329.md)
rebuilt trees without checkpoint reuse and reproduced all 366,068 historical
root groups, 5,959,560 native ortholog pairs and their species/confidence
annotations. The inferred species-tree bytes also matched. The
[three-way downstream comparison](QFO_CANONICAL_RESULT_22333.md) then evaluated
canonical candidates, reusing only 24,263 input-identical raw-tree checkpoints
and rerunning species-tree inference, rooting, reconciliation and membership
filtering. Relative to either historical or fresh retained order, canonical
predictions lost 110 pairs, gained 85 pairs and changed seven shared-pair
annotations. One old root group was replaced by four groups; 44 genes belong
to the union of changed root groups, not necessarily 44 individual
reassignments. All three species trees were byte-identical. Candidate
membership and constraints changed together, so the experiment does not
isolate their individual causal contributions.

These controls establish retained-order downstream reproducibility, but
contradict canonical prediction equivalence on QfO. They are not a fresh
search, independent accuracy confirmation or controlled timing comparison.
All 5,959,535 canonical native pairs passed independent conversion validation
with zero mapping loss. Their [six-endpoint scoring protocol](QFO_CANONICAL_SCORING_PROTOCOL_20260927.md)
was followed by a [completed and independently validated assessment](QFO_CANONICAL_ASSESSMENT_RESULT_22336.md).
GO, EC, VGNC, SwissTrees and TreeFam-A scores were exactly unchanged. FAS was
0.762588129455 versus historical 0.762993312100; native unseeded sampling
prevents attributing that difference solely to candidate ordering. The
secondary six-metric mean was 0.761442488335 versus 0.761510018776, with the
entire change arising from FAS. This heterogeneous mean is not F1, and native
uncertainty fields do not establish paired confidence intervals. Both
evaluated arms remain separately recorded; no historical score was replaced,
ordering selected for its score or default retuned. Unchanged scores on five
endpoints do not negate the observed prediction differences.

Historical installation manifests retain their original tool versions and
must not be interpreted as secure installation recommendations. The original
CPU-wheel lock pins pip and setuptools versions affected by 11 retained
repository advisories. A separately tested
[patched development-installation lock](publication_baseline_patched_requirements_20260919.txt)
and [local-wheel, smoke and advisory-range evidence](PUBLICATION_INSTALLER_SECURITY_20260919.md)
are available without altering frozen benchmark environments. The September
20 recheck finds no affected recorded versions in that patched installation
for those 11 ranges. This does not establish a secure complete build chain,
current installed-environment clearance, portable release or closed repository
alerts; the historical lock remains evidence only, not for new installation.

A subsequent [reader-only security upgrade](READER_SECURITY_UPGRADE_20260927.md)
replaced Biopython 1.86 with 1.87 after a twelfth repository advisory was
recorded. The five-package reader installation passed dependency checks,
before/after wheel-payload audits and all four scientific readers on the
16-gene fixture, with unchanged scientific fields. None of its verified
versions fell within the 12 retained advisory ranges. This bounded check
does not establish comprehensive security or close historical repository
alerts; the inference environment and historical locks were not changed.

The [full OrthoBench scoring archive restoration](OB_SCORING_ARCHIVE_20260927.md)
recomputed the complete 70-family score object from the retained 59,770-group
partition and 251,378-gene universe outside the checkout. The score file
matched byte-for-byte, including F1 74.10607351873405%. Its 40-file archive
excludes raw reference data, installed environments and native tools; those
inputs and the patched reader were supplied separately. This demonstrates
same-host scoring restoration, not fresh native inference, new accuracy
evidence or a complete distributable workflow.

An [integrated controller](INTEGRATED_WORKFLOW_20260927.md) subsequently
completed fresh offline installation, native inference and independent
readback/scoring in eight stages on the 16-gene fixture. Synthetic reference
labels test integration, not biological accuracy. An initial preflight
identified two unused absolute MAFFT convenience links; fresh asset copies
replace them with relative links and reject escaping links. Earlier
bounded execution traces remain valid, but the old whole asset tree was
not independently portable. The subsequent
[full-data execution protocol](INTEGRATED_FULL_OB_PROTOCOL_20260927.md)
was frozen before job 22337, which subsequently completed all eight stages
without native checkpoint reuse. Its [independent admission](INTEGRATED_FULL_OB_RESULT_22337.md)
checked provenance and installed packages, reran the four scientific readers,
and recomputed both full partitions' scores. All 59,770 groups covering
251,378 genes and all 70 reference-family score records matched the historical
baseline; root partition bytes were identical. Weighted F1 remained
74.10607351873405%. This establishes same-host integrated reproduction, not
new biological validation. Whole-workflow shared-host measurements are not
inference-only or controlled comparative timings.

A [separately reconstructed base runtime](RECONSTRUCTED_BASE_FIXTURE_20260927.md)
also completed the eight-stage fixture with identical root-group bytes and
scientific fields. It used 19 hash-verified Conda archives and an explicit
pip-wheel overlay, not a solver-complete Conda lock. The traced fixture made
no recorded file access containing the original interpreter or checkout
prefix; acquisition and bootstrap still used the original Conda installer,
and OS libraries remained shared. A [payload audit](RECONSTRUCTED_CONDA_PAYLOADS_20260927.md)
checked 6,664 declared Conda entries, followed by successful
[replay of all 195 prefix transformations](RECONSTRUCTED_PREFIX_REPLAY_20260927.md)
using Conda's own implementation. One Python cache differed in serialized
bytes; recompiling its installed source reproduced its header and compared
code-object fields, not byte identity. These checks support same-host fixture
reconstruction, not cross-host restoration, complete runtime closure or
full-dataset scientific validation. They do not apply retroactively to job
22337, which used the earlier base interpreter.

Subsequently, a [prespecified full-data attempt](RECONSTRUCTED_FULL_OB_PROTOCOL_20260929.md)
used the reconstructed base for the controller, venv creation and offline
installation, preserving all scientific settings and supplied assets.
[Job 22376 and separate independent verification](RECONSTRUCTED_FULL_OB_RESULT_22376.md)
completed successfully. All eight stages ran without checkpoint reuse;
package inventory/payload checks and four independent scientific readers
passed. All 59,770 root groups and complete scores for all 70 reference
families matched job 22337. Native pair, pair-confidence, reconciliation-node
and hierarchical-group TSVs were byte-identical. This closes the fixture-only
gap for the reconstructed-base execution path on this host, not cross-host
restoration, complete OS closure or redistribution clearance. Existing input,
reader and native-tool assets remained locally supplied. Its shared-host
elapsed time does not enter the controlled comparative timing panel.

The later [explicit asset assembly](PUBLICATION_RUNTIME_ASSEMBLY_20261002.md)
connects independently acquired wheels, the exact source-reconstructed project
wheel, prepared MAFFT/FastTree and the frozen 31-module independent-reader
closure without old installation trees. Its explicitly selected executor
lane completes all ten installation/native/readback stages on the 16-gene
fixture, reproduces five native outputs and verifies 5,754 installed payload
files with all 883 supplied base-site files unchanged. A mistaken outer
root-group/reconciled-family count assertion is retained and corrected by
readback only, without a second native run. This does not re-admit full-data
results, establish independent accuracy or remove OS/security/rights limits.

The [native-build source handoff](PUBLICATION_NATIVE_HANDOFF_20261002.md)
includes those executed recipes, exact support locks and integration metadata
alongside the dated nine-page review, eight-tool table and retained-count
replays. Its 1,936 archive members verify after fresh extraction with original
mounted paths denied by an observed Python-event guard. Preserve the initial
TMPDIR placement failure; use the same archive and unchanged guard under
explicit /tmp. No native/numerical experiment is repeated for this source
profile update. Raw data, wheels, tool binaries and the base/OS runtime remain
separately provisioned; this is not complete native payload delivery, syscall
containment, a cleared public release or an archival accession.

A [primary-source data-rights register](PUBLICATION_DATA_RIGHTS_20260918.md)
distinguishes QfO deposit, UniProt, WGD, BUSCO, OrthoBench and YGOB terms.
In particular, BUSCO software and dataset licenses differ. OrthoBench/YGOB
redistribution and exact Three Kingdoms input notices remain unresolved.
No repository-wide license or local archive is treated as blanket clearance
for acquired material; final file-level and software-notice review is pending.
An [exact-artifact notice export](INTEGRATED_DEPENDENCY_NOTICES_20260927.md)
collects 80 embedded notice candidates from the 12 distinct wheels selected
by the integrated inference and reader installations. All exported bytes
verify after relocation. This supplies review material, not complete
compiled-component attribution, license compatibility or redistribution
clearance for runtimes, tools or datasets.

A [relocatable figure-evidence bundle](PUBLICATION_FIGURE_BUNDLE_20260918.md)
preserves 18 retained panels, their 61 outputs, original manifests and
directly recorded dependencies from committed source revisions. Its standalone
verifier passed after archive extraction outside the repository. This is a
byte-identity and relocation check, not regeneration of all scientific results,
native inference, or clearance of redistribution rights. The archive remains
local and is not the complete publication deposit.

A [corrected-QfO figure supplement](PUBLICATION_CORRECTED_FIGURE_BUNDLE_20260919.md)
separately preserves the corrected factorial, composition-stratified and
comparator figures and their direct dependencies from commit `5132dda`.
Its 27-file export, including 12 outputs, passed isolated verification after
extraction outside the repository. The earlier 11-file factorial export from
`706fc03` is retained; historical plotter identities are not overwritten.
This is evidence preservation, not statistical or native-inference
regeneration. These archives have not been deposited, and redistribution
review remains incomplete.

The [corrected factorial statistical reproduction](QFO_CORRECTED_FACTORIAL_REPRODUCTION_20260919.md)
separately exported committed counts and numerical code outside the checkout.
All eight cell estimates and all 42 paired endpoints reproduced exactly under
isolated Python with the frozen 100,000 draws and seed. This does not repeat
native inference, official scoring or raw-source admission.

A [completed QfO parameter numerical archive](QFO_PARAMETER_NUMERICAL_COMPONENT_RESULT_20261001.md)
preserves the exact seven-arm report, large provenance manifests, original
sources and all six table/figure files. All 25 regular archive members were
byte-checked, and a fresh extraction outside the checkout passed copied
standard-library verification and all 18 numerical endpoints. A Python audit
guard rejected a canary checkout read, then observed no original-path events
during reproduction or project-module imports. This used the existing NumPy
version on the same host; it is not OS containment, hermetic installation,
native inference/reference recount, rights clearance or a public release.

The [SwissTrees descriptive-table arithmetic component](SWISS_DESCRIPTIVE_COMPONENT_20261002.md)
separately restores with standard-library Python 3.12 and reproduces 208 rows
and 984 score/difference cells across four tables and all eight methods.
It excludes the raw dependency panels and does not rerun native annotation
admission, scoring or bootstrap intervals. Its numerical verification must
not be interpreted as a fresh biological validation of the retained labels.

The [private raw-input archive workflow](SWISS_RAW_ARCHIVE_RESTORATION_20261002.md)
adds actual restoration of the complete duplication and fragment panels,
preserving all 11/1,774 ordered original record occurrences and their immutable
identities. Both archives restore under standard-library system Python 3.12;
a fresh Python 3.10 child passes all 27 affected regression/options cases,
including all four real raw exports. Explicit independent SHA256 bindings,
not automatic lookup or expected-hash recomputation, supply the new paths.
The guards block original-checkout and host-counter reads and child processes,
but do not establish OS containment. Native annotation extraction/admission,
inference, benchmark scoring and bootstrap are not rerun. Input-only raw
archives stay private/local and unuploaded, without new redistribution rights.
The 233 focused local cases overlap, rather than add independent scientific
evidence to, the 27 copied cases. Historical failed controls and archives
remain intact; this is not the complete executable study release.

A [relocated reproduction workflow](SWISS_RELOCATED_REPRODUCTION_20260917.md)
exports the SwissTrees comparator analysis from a fixed commit and reruns it in
a fresh hash-pinned Python environment. Its numerical results and Markdown
table reproduce exactly, and the figure workflow completes. This validates a
bounded statistical workflow, not native inference or raw benchmark acquisition
and scoring, and does not resolve third-party redistribution permissions.

The [OrthoBench factorial relocation check](ORTHOBENCH_FACTORIAL_REPRODUCTION_20260918.md)
also exported committed analysis inputs and code outside the checkout. All
eight cells and the 20,000-draw paired analysis reproduced exactly from the
70-family sufficient statistics in an isolated Python invocation. This used
the existing analysis virtual environment on the same host, not a fresh
installation or independent native-inference/scoring reproduction.

Code and analysis milestones are tracked in the authorized repository.
Machine-readable reports retain input, source, and output hashes where
audited; large raw datasets and working outputs are not included in normal
source commits. The figure bundle is generated from the comparison JSON
and includes a provenance manifest. Absolute local paths are provenance,
not portable download locations. A complete executable study bundle, complete
dependency lock, raw-output inventory, redistribution-permission review,
versioned release, and archival deposition remain unfinished. No archive
accession or publication DOI has been assigned by this work.

See the [claim-to-evidence checklist](PUBLICATION_CLAIMS_20260916.md) before
strengthening conclusions or describing this package as publication-ready.
