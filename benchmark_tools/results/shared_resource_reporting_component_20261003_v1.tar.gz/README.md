shared_host_resource_reporting_not_raw_measurement_reproduction

Replay with component.py and the externally supplied bundle.json SHA-256.
Original absolute evidence paths are provenance only and are not read.
Tables and PNG pixels reproduce; raw cgroup/runtime/native evidence is not revalidated.
Excluded attempts and incomplete repeats remain explicit. No isolated speedup or publication readiness.
