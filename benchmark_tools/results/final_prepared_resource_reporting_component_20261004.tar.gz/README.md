shared_host_resource_reporting_not_raw_measurement_reproduction

Use component.py verify/replay with externally retained bundle.json SHA-256.
No original evidence paths are opened; metadata paths are provenance only.
Replay preserves excluded measurements, pre-native aborts and incomplete repeats.
This is not raw-accounting/native reproduction, isolated speed evidence or publication readiness.
Prose replay includes resource_section.md from the same reviewed snapshot.
